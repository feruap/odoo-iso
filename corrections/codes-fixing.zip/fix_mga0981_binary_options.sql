-- ============================================================================
-- Script para corregir las opciones binarias de MGA0981 en semiterminados
-- Fecha: 2026-03-01
-- ============================================================================
-- Problema: Los textos de binary_option_pass y binary_option_fail tienen
-- caracteres corruptos (???????) en lugar de símbolos como ≥ o ≤
-- ============================================================================

BEGIN;

SELECT 'Corrigiendo opciones binarias de MGA0981:' as info;

-- Ver estado actual
SELECT id, product_tmpl_id, binary_option_pass, binary_option_fail
FROM amunet_quality_parameter_specification_config
WHERE id IN (78127, 78134, 78141, 78148, 78182, 78228);

-- Corregir STBAC01, STBCH01, STBTR01, STBDN01 (2.5 ml)
UPDATE amunet_quality_parameter_specification_config
SET binary_option_pass = '≥ 2.5 ml (Variación de volumen aceptable)',
    binary_option_fail = '< 2.5 ml (Variación de volumen fuera de especificación)',
    write_date = NOW()
WHERE id IN (78127, 78134, 78141, 78148)
RETURNING id, specification_name, binary_option_pass, binary_option_fail;

-- Corregir STBHB01 (1000 µl)
UPDATE amunet_quality_parameter_specification_config
SET binary_option_pass = '≥ 1000 µl (Variación de volumen aceptable)',
    binary_option_fail = '< 1000 µl (Variación de volumen fuera de especificación)',
    write_date = NOW()
WHERE id = 78182
RETURNING id, specification_name, binary_option_pass, binary_option_fail;

-- Corregir STBTR02 (500 µl)
UPDATE amunet_quality_parameter_specification_config
SET binary_option_pass = '≥ 500 µl (Variación de volumen aceptable)',
    binary_option_fail = '< 500 µl (Variación de volumen fuera de especificación)',
    write_date = NOW()
WHERE id = 78228
RETURNING id, specification_name, binary_option_pass, binary_option_fail;

-- ============================================================================
-- Actualizar también los QCs existentes con estos productos
-- ============================================================================

SELECT 'Actualizando detalles de QCs con MGA0981:' as info;

-- Buscar detalles de QC con MGA0981 para estos productos
SELECT tld.id, tld.check_id, tld.name, tld.binary_option_pass, tld.binary_option_fail
FROM amunet_quality_test_line_detail tld
JOIN amunet_quality_test_line tl ON tl.id = tld.test_line_id
WHERE tl.parameter_id = 80AND tld.evaluation_type = 'binary_selection';

COMMIT;

-- ============================================================================
-- RESUMEN
-- ============================================================================
-- Se corrigieron las opciones binarias de MGA0981 para:
-- - STBAC01, STBCH01, STBTR01, STBDN01: ≥ 2.5 ml / < 2.5 ml
-- - STBHB01: ≥ 1000 µl / < 1000 µl
-- - STBTR02: ≥ 500 µl / < 500 µl
-- ============================================================================
