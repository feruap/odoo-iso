-- ============================================================================
-- Script para actualizar manualmente el QC262 (STBTR01)
-- Fecha: 2026-03-01
-- ============================================================================

BEGIN;

SELECT 'Actualizando QC262 (STBTR01):' as info;

-- ============================================================================
-- 1. Actualizar MGA0981 (detalle 1027) - Cambiar a binary_selection
-- ============================================================================

SELECT 'Antes - MGA0981:' as info;
SELECT id, name, evaluation_type, specification_config_id, binary_option_pass, binary_option_fail
FROM amunet_quality_test_line_detail WHERE id = 1027;

UPDATE amunet_quality_test_line_detail
SET evaluation_type = 'binary_selection',
    specification_config_id = 78141,
    binary_option_pass = '>= 2.5 ml (Variacion de volumen aceptable)',
    binary_option_fail = '< 2.5 ml (Variacion de volumen fuera de especificacion)',
    write_date = NOW()
WHERE id = 1027
RETURNING id, name, evaluation_type, specification_config_id, binary_option_pass, binary_option_fail;

-- ============================================================================
-- 2. Actualizar MAVI-07 (detalle 1243) - Actualizar text_phrase_mapping
-- ============================================================================

SELECT 'Antes - MAVI-07:' as info;
SELECT id, name, evaluation_type, specification_config_id FROM amunet_quality_test_line_detail WHERE id = 1243;

UPDATE amunet_quality_test_line_detail
SET specification_config_id = 78146,
    text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "phrase_template": "{0} con {1}.", "success_message": "Interpretacion de resultados correcta.", "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Linea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Linea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Linea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Linea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Linea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Linea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Linea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Linea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Linea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Linea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id = 1243
RETURNING id, name, evaluation_type, specification_config_id;

-- ============================================================================
-- Verificación final
-- ============================================================================

SELECT 'Estado final del QC262:' as info;

SELECT tld.id, tld.name, tld.evaluation_type, tld.specification_config_id, 
       CASE WHEN tld.evaluation_type = 'binary_selection' THEN tld.binary_option_pass ELSE 'N/A' END as option_pass,
       CASE WHEN tld.text_phrase_mapping LIKE '%evaluation%' THEN 'SI' ELSE 'NO' END as tiene_evaluation
FROM amunet_quality_test_line_detail tld
WHERE tld.check_id = 262
ORDER BY tld.id;

COMMIT;
