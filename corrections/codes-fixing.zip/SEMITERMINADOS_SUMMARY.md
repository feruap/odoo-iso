====================================================================================================
RESUMEN DE PRODUCTOS SEMITERMINADOS CON SUS DETERMINACIONES
====================================================================================================


================================================================================
PRODUCTO: STACM01 - Vial con aceite mineral
================================================================================

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STALA01 - Almohadilla con alcohol
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-094 - Desempeño de la almohadilla con alcohol
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBAC01 - Vial con soluci??n de corrimiento para muestras de sangre, suero o plasma
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -29.00 - 31.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 7.40

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: >= 2.5 ml (Variacion de volumen aceptable)
        [X] No cumple: < 2.5 ml (Variacion de volumen fuera de especificacion)

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBBM01 - Vial con soluci??n de corrimiento para PCR r??pida
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07
        [W] WIDGET ESPECIAL: mavi_07
        [V] Valor objetivo: 0.00
        [OK] Cumple: Negativo Muestra Negativa
        [X] No cumple: Positivo Muestra Negativa

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -29.00 - 31.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 7.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -100.00 - 300.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBCH01 - Vial con soluci??n de corrimiento para muestras de sangre, suero o plasma con Chem
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 7.40

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: >= 2.5 ml (Variacion de volumen aceptable)
        [X] No cumple: < 2.5 ml (Variacion de volumen fuera de especificacion)

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBDN01 - Vial con soluci??n de corrimiento AC+PBS
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 7.40

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: >= 2.5 ml (Variacion de volumen aceptable)
        [X] No cumple: < 2.5 ml (Variacion de volumen fuera de especificacion)

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBHB01 - Vial individual con soluci??n de corrimiento hba1ac
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 7.50

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: >= 1000 ul (Variacion de volumen aceptable)
        [X] No cumple: < 1000 ul (Variacion de volumen fuera de especificacion)

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBPR01 - Vial con soluci??n de corrimiento para pruebas ssp
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07
        [W] WIDGET ESPECIAL: mavi_07
        [V] Valor objetivo: 0.00
        [OK] Cumple: Negativo Muestra Negativa
        [X] No cumple: Positivo Muestra Negativa

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBPR02 - Vial con soluci??n de corrimiento para pruebas tr
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07
        [W] WIDGET ESPECIAL: mavi_07
        [V] Valor objetivo: 0.00
        [OK] Cumple: Negativo Muestra Negativa
        [X] No cumple: Positivo Muestra Negativa

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBPR03 - Vial con soluci??n de corrimiento para pruebas heces
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07
        [W] WIDGET ESPECIAL: mavi_07
        [V] Valor objetivo: 0.00
        [OK] Cumple: Negativo Muestra Negativa
        [X] No cumple: Positivo Muestra Negativa

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBTR01 - Vial con soluci??n de corrimiento para muestras de tracto respiratorio
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 9.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: >= 2.5 ml (Variacion de volumen aceptable)
        [X] No cumple: < 2.5 ml (Variacion de volumen fuera de especificacion)

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STBTR02 - Vial individual con soluci??n de corrimiento para muestras de tracto respiratorio
================================================================================

  [*] DETERMINACION: MGA 0181 - Color de la solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 9.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: >= 500 ul (Variacion de volumen aceptable)
        [X] No cumple: < 500 ul (Variacion de volumen fuera de especificacion)

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-057 - Gotas obtenidas
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STCON01 - Control negativo
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-078 - Aspectos del liofilizado
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-114 - Funcionalidad del control negativo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STCOP01 - Control positivo
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-078 - Aspectos del liofilizado
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-113 - Funcionalidad del control positivo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STCSA01 - Colector de saliva (para alcohol en saliva)
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 18.00 - 22.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-093 - Funcionalidad
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STDSC01 - Desecantes
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [R] Rango: -5.00 - 5.00

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-098 - Peso
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.10 - 0.10

  [*] DETERMINACION: VAMA-099 - Absorción de humedad
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STGEL01 - Gel refrigerante
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [R] Rango: -1.00 - 1.00

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 16.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-098 - Peso
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-100 - Determinación de funcionalidad del gel refrigerante
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -18.00 - 18.00

================================================================================
PRODUCTO: STGOT01 - Gotero capilar
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 5.00 - 15.00

================================================================================
PRODUCTO: STGOT02 - Gotero capilar chico punta larga
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 0.00 - 10.00

================================================================================
PRODUCTO: STGOT03 - Gotero capilar grande punta larga
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 15.00 - 25.00

================================================================================
PRODUCTO: STGOT04 - Gotero de 25  ??????l
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 20.00 - 30.00

================================================================================
PRODUCTO: STGOT05 - Gotero general de 40  ??????l
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 23.00 - 33.00

================================================================================
PRODUCTO: STGOT06 - Gotero Antidoping SSP
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 23.00 - 33.00

================================================================================
PRODUCTO: STGOT07 - Gotero con punta capilar
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: binary_with_notes
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-038 - Funcionalidad del gotero
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 15.00 - 25.00

================================================================================
PRODUCTO: STGRA01 - Gradilla de carton
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHEB01 - Vial con soluci??n de corrimiento para muestras de heces
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0701 - pH
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 6.90 - 7.90

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 1.00 - 3.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHIE01 - Hielera chica
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [R] Rango: -0.50 - 0.50

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: OLD-118 - [REDUNDANT] Apariencia del empaque
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 1.00
        [OK] Cumple: Sin Polvo
        [X] No cumple: Con Polvo

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-023 - Capacidad de cierre
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHIE02 - Hielera mediana
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [R] Rango: -0.50 - 0.50

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: OLD-118 - [REDUNDANT] Apariencia del empaque
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 1.00
        [OK] Cumple: Sin Polvo
        [X] No cumple: Con Polvo

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-023 - Capacidad de cierre
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHIE03 - Hielera grande
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [R] Rango: -0.50 - 0.50

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

  [*] DETERMINACION: OLD-118 - [REDUNDANT] Apariencia del empaque
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Letra legible
        [X] No cumple: Letra ilegible

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-023 - Capacidad de cierre
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHIS01 - Hisopo nasofaringeo
================================================================================

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHIS02 - Hisopo bucal
================================================================================

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-093 - Funcionalidad
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -9.70 - 10.30

================================================================================
PRODUCTO: STHIS03 - Hisopo vaginal
================================================================================

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-093 - Funcionalidad
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -9.70 - 10.30

================================================================================
PRODUCTO: STHIS04 - Cepillo cervical
================================================================================

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-092 - Expulsi??????n de la cabeza del cepillo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: La cabeza del cepillo es
        [X] No cumple: no es expulsada completamente por el tubo transparente.

================================================================================
PRODUCTO: STHIS05 - Hisopo cervical (auto-toma)
================================================================================

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-104 - Funcionalidad del mecanismo extensible/retráctil
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STHIS06 - Hisopo general
================================================================================

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-093 - Funcionalidad
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -9.70 - 10.30

================================================================================
PRODUCTO: STLAN01 - Lanceta
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-095 - Funcionalidad de lanceta
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STRDI01 - Vial con reactivo diluyente
================================================================================

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STREX01 - Vial con reactivo de extracci??n 1
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07
        [W] WIDGET ESPECIAL: mavi_07
        [V] Valor objetivo: 0.00
        [OK] Cumple: Negativo Muestra Negativa
        [X] No cumple: Positivo Muestra Negativa

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: conditional_numeric_range
        [W] WIDGET ESPECIAL: conditional_numeric_range
        [R] Rango: 9.50 - 10.50

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

================================================================================
PRODUCTO: STREX02 - Vial con reactivo de extracci??n 2
================================================================================

  [*] DETERMINACION: MAVI-07 - Visualización de líneas “resultado base”
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_07
        [W] WIDGET ESPECIAL: mavi_07
        [V] Valor objetivo: 0.00
        [OK] Cumple: Negativo Muestra Negativa
        [X] No cumple: Positivo Muestra Negativa

     [>] Tipo de Evaluacion: mavi_07_ternary
        [W] WIDGET ESPECIAL: mavi_07_ternary
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-09 - Desempeño del tiempo de flujo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MGA 0981 - Variación de volumen
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: conditional_numeric_range
        [W] WIDGET ESPECIAL: conditional_numeric_range
        [R] Rango: 9.50 - 10.50

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -0.50 - 0.50

================================================================================
PRODUCTO: STRSE01 - Vial con reactivo seco
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-078 - Aspectos del liofilizado
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-115 - Funcionalidad del reactivo seco
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STSAL01 - Vial con soluci??n salina
================================================================================

  [*] DETERMINACION: VAMA-004 - Partículas en solución
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STTBT01 - Tubo con tapa desecante
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -1.00 - 1.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -1.00 - 1.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-052 - Funcionalidad del tubo con tapa desecante
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STTCC01 - Tubo capilar de cristal
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Sin Deformidad o deterioro
        [X] No cumple: Con Deformidad o deterioro

  [*] DETERMINACION: VAMA-097 - Funcionalidad del tubo capilar
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00
        [OK] Cumple: Si
        [X] No cumple: No llena completamente

================================================================================
PRODUCTO: STTCS01 - Tubo colector de saliva (para alcohol en saliva)
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 18.0 - 22.0

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-096 - Funcionalidad del vial y tamaño de gota
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: multi_condition_numeric
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [R] Rango: 40.00 - 50.00

================================================================================
PRODUCTO: STTCT01 - Tubo colector y tapa cuenta gotas
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -2.00 - 2.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-044 - Funcionalidad del tubo de extracción
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: vama_044
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [R] Rango: -5.00 - 5.00

================================================================================
PRODUCTO: STTCT02 - Tubo colector con union a la tapa cuentagotas (con tapa)
================================================================================

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -2.00 - 2.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: VAMA-044 - Funcionalidad del tubo de extracción
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: vama_044
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [R] Rango: -5.00 - 5.00

================================================================================
PRODUCTO: STVIA05 - Vial 5 ml para buffer
================================================================================

  [*] DETERMINACION: MA-096 - Funcionalidad del vial y tama??????o de gota
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: multi_condition_numeric
        [R] Rango: 40.00 - 50.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: -2.00 - 2.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STVIR01 - Vial 5 ml para buffer con recolector
================================================================================

  [*] DETERMINACION: MA-096 - Funcionalidad del vial y tama??????o de gota
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: multi_condition_numeric
        [R] Rango: 40.00 - 50.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 9.00 - 11.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

================================================================================
PRODUCTO: STVIR02 - Vial 5 ml para buffer sin recolector
================================================================================

  [*] DETERMINACION: MA-096 - Funcionalidad del vial y tama??????o de gota
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: multi_condition_numeric
        [R] Rango: 40.00 - 50.00

     [>] Tipo de Evaluacion: numeric_range
        [V] Valor objetivo: 0.00

     [>] Tipo de Evaluacion: vama_multi_check
        [W] WIDGET ESPECIAL: vama_multi_check
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-04 - Aspectos
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00

  [*] DETERMINACION: MAVI-11 - Longitud y/o grosor
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: mavi_11_height
        [R] Rango: -2.00 - 2.00

     [>] Tipo de Evaluacion: numeric_range
        [R] Rango: 9.00 - 11.00

  [*] DETERMINACION: OLD-119 - [REDUNDANT] Estructura del hisopo
  ------------------------------------------------------------

     [>] Tipo de Evaluacion: binary_selection
        [V] Valor objetivo: 0.00