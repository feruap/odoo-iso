# ANÁLISIS DE PRODUCTOS SEMITERMINADOS VS DOCUMENTACIÓN

## Resumen Ejecutivo

Este documento presenta el análisis comparativo entre las configuraciones de productos semiterminados en la base de datos Odoo y las especificaciones definidas en la documentación "CC Semiterminados.docx".

**Fecha de análisis:** 2026-02-27
**Total de productos con parámetros de semiterminados:** 200+ productos
**Productos analizados detalladamente:** 10 productos clave

---

## Productos Semiterminados Identificados

### Mapeo de códigos de documentación a productos en BD:

| Código Doc | Producto en BD | ID Template | Estado |
|------------|----------------|-------------|--------|
| STTCS01 | Tubo colector de saliva (para alcohol en saliva) | 1012 | ⚠️ REVISAR |
| STTCT01 | Tubo colector y tapa cuenta gotas | 986 | ⚠️ REVISAR |
| STTCT02 | Tubo colector con unión a la tapa cuentagotas (con tapa) | 987 | ⚠️ REVISAR |
| STALA01 | Almohadilla con alcohol | 984 | ✅ OK |
| STLAN01 | Lanceta | 985 | ✅ OK |
| STVIA05 | Vial 5 ml para buffer | 992 | ⚠️ REVISAR |
| STVIR01 | Vial 5 ml para buffer con recolector | 993 | ⚠️ REVISAR |
| STVIR02 | Vial 5 ml para buffer sin recolector | 994 | ⚠️ REVISAR |
| STTBT01 | Tubo con tapa desecante | 1014 | ⚠️ REVISAR |

---

## Especificaciones por Producto según Documentación

### 1. STTCS01 - Tubo colector de saliva (ID: 1012)

#### MAVI-04 (Aspectos):
| Código | Especificación | Criterio de Aceptación | Sistema |
|--------|----------------|------------------------|---------|
| 1 | Polvo | Sin polvo | Selección Sin/Con |
| 2 | Manchas y/o suciedad | Sin manchas y/o suciedad | Selección Sin/Con |
| 3 | Rasgaduras | Sin rasgaduras | Selección Sin/Con |
| 5 | Deformidad o deterioro | Sin deformidad o deterioro | Selección Sin/Con |

#### MAVI-11 (Longitud y/o grosor):
| Componente | Especificación | Sistema |
|------------|----------------|---------|
| Tapa del tubo colector - Altura | 20 mm ± 2 mm | Campo numérico decimal |
| Tubo colector - Altura | 65 mm ± 2 mm | Campo numérico decimal |
| Tubo colector con tapa - Altura | 75 mm ± 2 mm | Campo numérico decimal |

#### VAMA-096 (Funcionalidad y tamaño de gota):
| Paso | Especificación | Criterio |
|------|----------------|----------|
| 1 | Funcionamiento del Vial | Correcto (Opción A) |
| 2 | Número de gotas | ≥ 5 gotas |
| 3 | Volumen de gota promedio | 45 µl ± 5 µl (40-50 µl) |

---

### 2. STTCT01 - Tubo colector y tapa cuentagotas (ID: 986)

#### MAVI-04 (Aspectos):
| Código | Especificación | Criterio de Aceptación |
|--------|----------------|------------------------|
| 2 | Manchas y/o suciedad | Sin manchas y/o suciedad |
| 3 | Rasgaduras | Sin rasgaduras |
| 5 | Deformidad o deterioro | Sin deformidad o deterioro |

#### MAVI-11 (Longitud y/o grosor):
| Componente | Especificación | Sistema |
|------------|----------------|---------|
| Tapa cuentagotas - Altura | 21 mm ± 2 mm | Campo numérico decimal |
| Tapa cuentagotas - Diámetro | 8 mm ± 2 mm | Campo numérico decimal |
| Tubo colector - Altura | 50 mm ± 2 mm | Campo numérico decimal |
| Tubo colector - Diámetro | 10 mm ± 2 mm | Campo numérico decimal |

#### VAMA-044 (Funcionalidad del tubo colector con tapa cuentagotas):
| Paso | Especificación | Criterio |
|------|----------------|----------|
| 1 | Número de gotas | ≥ 5 gotas |
| 2 | Volumen de gota promedio | 45 µl ± 5 µl (40-50 µl) |
| 3 | Unión tapa cuentagotas y tubo colector | Adecuada (Opción A) |
| 4 | Volumen de llenado | 1550 µl ± 10 µl (1540-1560 µl) |

---

### 3. STALA01 - Almohadilla con alcohol (ID: 984)

#### MAVI-04 (Aspectos):
| Código | Especificación | Criterio de Aceptación |
|--------|----------------|------------------------|
| 1 | Polvo | Sin polvo |
| 2 | Manchas y/o suciedad | Sin manchas y/o suciedad |
| 3 | Rasgaduras | Sin rasgaduras |
| 5 | Deformidad o deterioro | Sin deformidad o deterioro |

#### VAMA-094 (Desempeño de la almohadilla con alcohol):
| Paso | Especificación | Criterio |
|------|----------------|----------|
| 1 | Estado de la almohadilla | Húmeda (Opción A) |
| 2 | Presencia de alcohol | Con presencia de alcohol (Opción A) |

---

### 4. STLAN01 - Lanceta (ID: 985)

#### MAVI-04 (Aspectos):
| Código | Especificación | Criterio de Aceptación |
|--------|----------------|------------------------|
| 1 | Polvo | Sin polvo |
| 2 | Manchas y/o suciedad | Sin manchas y/o suciedad |
| 3 | Rasgaduras | Sin rasgaduras |
| 5 | Deformidad o deterioro | Sin deformidad o deterioro |

#### VAMA-095 (Funcionalidad de lanceta):
| Especificación | Criterio |
|----------------|----------|
| Presencia de punción | Presencia (Opción A) |

---

### 5. STVIA05 - Vial 5 ml para buffer (ID: 992)

#### MAVI-04 (Aspectos):
| Código | Especificación | Criterio de Aceptación |
|--------|----------------|------------------------|
| 1 | Polvo | Sin polvo |
| 2 | Manchas y/o suciedad | Sin manchas y/o suciedad |
| 3 | Rasgaduras | Sin rasgaduras |
| 5 | Deformidad o deterioro | Sin deformidad o deterioro |

#### MAVI-11 (Longitud y/o grosor):
| Componente | Especificación | Sistema |
|------------|----------------|---------|
| Tapa cuentagotas - Altura | 21.5 mm ± 2 mm | Campo numérico decimal |
| Tapa cuentagotas - Diámetro | 12.5 mm ± 2 mm | Campo numérico decimal |
| Tapa - Altura | 12 mm ± 2 mm | Campo numérico decimal |
| Vial - Altura | 7.5 mm ± 2 mm | Campo numérico decimal |

#### VAMA-096 / MA-096 (Funcionalidad del vial y tamaño de gota):
| Paso | Especificación | Criterio |
|------|----------------|----------|
| 1 | Funcionamiento del Vial | Correcto (Opción A) |
| 2 | Número de gotas | ≥ 5 gotas |
| 3 | Volumen de gota promedio | 45 µl ± 5 µl (40-50 µl) |

---

## Problemas Identificados

### 1. VAMA-096 (Funcionalidad y tamaño de gota)
- **Problema**: Los campos `multi_cond_num1_filled` y `multi_cond_num2_filled` no se actualizaban correctamente
- **Solución aplicada**: Convertidos a campos computados con `store=True`
- **Estado**: CORREGIDO

### 2. VAMA-044 (Funcionalidad del tubo colector)
- **Problema**: Similar a VAMA-096, los campos `vama044_*_filled` necesitan ser convertidos a campos computados
- **Estado**: PENDIENTE DE CORRECCIÓN

### 3. MAVI-04 (Aspectos)
- **Problema**: Múltiples configuraciones duplicadas por producto
- **Observación**: Cada producto tiene varias configuraciones MAVI-04 con diferentes IDs pero mismas especificaciones

---

## Recomendaciones

1. **VAMA-044**: Aplicar la misma corrección que VAMA-096 (convertir campos `*_filled` a computados)

2. **MAVI-04**: Limpiar configuraciones duplicadas, mantener solo una configuración activa por producto

3. **MAVI-11**: Verificar que los valores min/max coincidan con la documentación:
   - STTCS01: Altura tapa (18-22), Altura tubo (63-67), Altura total (73-77)
   - STTCT01: Altura tapa (19-23), Diámetro tapa (6-10), Altura tubo (48-52), Diámetro tubo (8-12)

---

## Hallazgos Específicos por Producto

### STTCS01 - Tubo colector de saliva (ID: 1012)

#### MAVI-11 - Comparación de especificaciones:

| Especificación | Documentación | Base de Datos | Estado |
|----------------|---------------|---------------|--------|
| Tapa del tubo colector - Altura | 20 mm ± 2 mm (18-22) | 20.00 - 20.00 | ❌ INCORRECTO |
| Tubo colector - Altura | 65 mm ± 2 mm (63-67) | 63.0 - 67.0 | ✅ CORRECTO |
| Tubo colector con tapa - Altura | 75 mm ± 2 mm (73-77) | 73.00 - 77.00 | ✅ CORRECTO |

**Problema encontrado:** La especificación "Tapa - Altura" tiene min=max=16 en algunos registros (debería ser18-22)

**Configuraciones adicionales encontradas (posiblemente incorrectas):**
- Tapa - Altura: 16.00 - 16.00 (debería ser18-22)
- Tapa - Ancho: 33.50 - 33.50 (no está en documentación STTCS01)
- Tubo - Altura: 93.00 - 93.00 (no está en documentación STTCS01)
- Tubo - Ancho: 28.00 - 28.00 (no está en documentación STTCS01)

#### VAMA-096:
- **Estado:** ✅ CORREGIDO - Campos `multi_cond_num1_filled` y `multi_cond_num2_filled` convertidos a computados

---

## Problemas Generales Identificados

### 1. Configuraciones Duplicadas
Cada producto tiene múltiples configuraciones para el mismo parámetro. Por ejemplo:
- Producto1012 tiene **40 configuraciones MAVI-04** y **37 configuraciones MAVI-11**
- Esto puede causar confusión en los QC sobre qué configuración usar

### 2. Especificaciones con min=max
Varias especificaciones tienen min_value = max_value, lo cual no permite tolerancia:
- Tapa - Altura: 16.00 - 16.00 (debería tener rango)
- Tapa - Ancho: 33.50 - 33.50 (debería tener rango)

### 3. VAMA-044 Pendiente de Corrección
Los campos `vama044_*_filled` necesitan ser convertidos a campos computados (igual que VAMA-096)

---

## Recomendaciones

### Inmediatas:
1. **Corregir VAMA-044**: Aplicar misma corrección que VAMA-096
2. **Corregir rangos MAVI-11**: Actualizar min/max según documentación
3. **Limpiar duplicados**: Mantener solo una configuración activa por especificación

### Largo Plazo:
1. Implementar validación de configuraciones antes de crear QC
2. Crear herramienta de migración para sincronizar documentación con BD
3. Establecer proceso de revisión periódica de configuraciones

---

## Próximos Pasos

1. ✅ Verificar configuraciones actuales en la base de datos
2. ✅ Comparar con especificaciones de documentación
3. ⏳ Generar script de corrección para discrepancias encontradas
4. ⏳ Aplicar correcciones y validar

---

*Generado automáticamente - Análisis de Semiterminados*
*Fecha: 2026-02-27*
