-- ============================================================================
-- Script de corrección para MAVI-07 en productos semiterminados
-- Fecha: 2026-03-01
-- ============================================================================
-- Problema identificado:
-- La lógica de MAVI-07 no está funcionando correctamente para semiterminados:
-- - Muestra Negativa: #5 = cumple, #1-4 = no cumple
-- - Muestra Positiva: #1-4 = cumple, #5 = no cumple
--
-- Solución: Agregar sección "evaluation" al text_phrase_mapping
-- ============================================================================
-- Productos afectados (solo semiterminados):
--   - STBAC01 (995), STBCH01 (996), STBTR01 (997), STBDN01 (998)
--   - STBBM01 (999), STBHB01 (1011), STREX01 (1007), STREX02 (1008)
-- ============================================================================

BEGIN;

-- Nuevo text_phrase_mapping con evaluation rules correctas para semiterminados
-- Muestra Negativa: #5 = pass, #1-4 = fail
-- Muestra Positiva: #1-4 = pass, #5 = fail

\set new_mapping '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}'

-- ============================================================================
-- Actualizar configuraciones de MAVI-07 para semiterminados
-- ============================================================================

SELECT 'Actualizando configuraciones MAVI-07 para semiterminados:' as info;

-- Ver configuraciones antes del cambio
SELECT id, product_tmpl_id, specification_name, evaluation_type
FROM amunet_quality_parameter_specification_config
WHERE id IN (78132, 78139, 78146, 78153, 78160, 78170, 78175, 78187);

-- Actualizar text_phrase_mapping con las reglas de evaluación correctas
UPDATE amunet_quality_parameter_specification_config
SET text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id IN (78132, 78139, 78146, 78153, 78160, 78170, 78175, 78187)
RETURNING id, product_tmpl_id, specification_name;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Configuraciones actualizadas:' as info;

SELECT id, product_tmpl_id, specification_name, evaluation_type,
       CASE WHEN text_phrase_mapping LIKE '%evaluation%' THEN 'SÍ tiene evaluation' ELSE 'NO tiene evaluation' END as tiene_evaluation
FROM amunet_quality_parameter_specification_config
WHERE id IN (78132, 78139, 78146, 78153, 78160, 78170, 78175, 78187);

COMMIT;

-- ============================================================================
-- RESUMEN DE CAMBIOS
-- ============================================================================
-- Se agregó la sección "evaluation" al text_phrase_mapping de MAVI-07 para:
-- - STBCH01 (config 78132)
-- - STBAC01 (config 78139)
-- - STBTR01 (config 78146)
-- - STBDN01 (config 78153)
-- - STBBM01 (config 78160)
-- - STREX01 (config 78170)
-- - STREX02 (config 78175)
-- - STBHB01 (config 78187)
--
-- Reglas de evaluación:
-- - Muestra Negativa: #5 = pass, #1-4 = fail
-- - Muestra Positiva: #1-4 = pass, #5 = fail
-- ============================================================================
