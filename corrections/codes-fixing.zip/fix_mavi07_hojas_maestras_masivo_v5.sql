-- ============================================================================
-- Script de corrección MASIVA MAVI-07 para Hojas Maestras (SPHMC*) - v5 CORREGIDO
-- Fecha: 2026-03-02
-- ============================================================================
-- Este script actualiza TODOS los productos SPHMC* con MAVI-07
-- EJECUTAR SOLO DESPUÉS DE VALIDAR SPHMC01
--
-- IMPORTANTE: El Paso1 guarda valores 'A' o 'B', no los labels
-- - A = Negativa
-- - B = Positiva
--
-- La evaluación compara:
-- - sample_type: valor del índice 0 ('A' o 'B')
-- - result: valor del índice 1 ('option_a', 'option_b', 'option_c')
--
-- Especificación "Muestra positiva":
-- - B (Positiva) + option_a = PASS
--
-- Especificación "Muestra negativa":
-- - A (Negativa) + option_b = PASS
-- ============================================================================

BEGIN;

-- ============================================================================
-- Actualizar TODAS las especificaciones "Muestra positiva" de SPHMC*
-- ============================================================================

SELECT 'Actualizando especificaciones Muestra positiva...' as info;

UPDATE amunet_quality_parameter_specification_config apsc
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "B", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE apsc.specification_name = 'Muestra positiva'
AND apsc.id IN (
    SELECT apsc2.id FROM amunet_quality_parameter_specification_config apsc2
    JOIN amunet_quality_parameter_product_rel rel ON rel.id = apsc2.product_parameter_rel_id
    JOIN product_template pt ON pt.id = rel.product_tmpl_id
    JOIN product_product pp ON pp.product_tmpl_id = pt.id
    WHERE pp.default_code LIKE 'SPHMC%'
    AND apsc2.specification_name = 'Muestra positiva'
    AND (apsc2.evaluation_type = 'vama_multi_check' AND apsc2.text_phrase_mapping IS NULL)
);

SELECT 'Actualizadas Muestra positiva: ' || ROW_COUNT() || ' registros' as resultado;

-- ============================================================================
-- Actualizar TODAS las especificaciones "Muestra negativa" de SPHMC*
-- ============================================================================

SELECT 'Actualizando especificaciones Muestra negativa...' as info;

UPDATE amunet_quality_parameter_specification_config apsc
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "B", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE apsc.specification_name = 'Muestra negativa'
AND apsc.id IN (
    SELECT apsc2.id FROM amunet_quality_parameter_specification_config apsc2
    JOIN amunet_quality_parameter_product_rel rel ON rel.id = apsc2.product_parameter_rel_id
    JOIN product_template pt ON pt.id = rel.product_tmpl_id
    JOIN product_product pp ON pp.product_tmpl_id = pt.id
    WHERE pp.default_code LIKE 'SPHMC%'
    AND apsc2.specification_name = 'Muestra negativa'
    AND (apsc2.evaluation_type = 'vama_multi_check' AND apsc2.text_phrase_mapping IS NULL)
);

SELECT 'Actualizadas Muestra negativa: ' || ROW_COUNT() || ' registros' as resultado;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Productos SPHMC* con MAVI-07 actualizados:' as info;

SELECT 
    pp.default_code as codigo,
    apsc.specification_name,
    apsc.evaluation_type,
    CASE WHEN apsc.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_parameter_product_rel rel
JOIN product_template pt ON pt.id = rel.product_tmpl_id
JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter ap ON ap.id = rel.parameter_id
JOIN amunet_quality_parameter_specification_config apsc ON apsc.product_parameter_rel_id = rel.id
WHERE ap.code = 'MAVI-07' 
AND pp.default_code LIKE 'SPHMC%'
ORDER BY pp.default_code, apsc.specification_name;

COMMIT;
