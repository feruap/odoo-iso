-- ============================================================================
-- Script de corrección MASIVA MAVI-07 para Hojas Maestras (SPHMC*) - v6 FINAL
-- Fecha: 2026-03-02
-- ============================================================================
-- Este script actualiza TODOS los productos SPHMC* con MAVI-07
-- EJECUTAR SOLO DESPUÉS DE VALIDAR SPHMC01
--
-- Cambios:
-- 1. Paso1 usa type: "select" con botones neutrales (sin colores verde/rojo)
-- 2. Paso2 sin prefijo "Opción A/B/C" - solo la descripción
-- ============================================================================

BEGIN;

-- ============================================================================
-- Actualizar TODAS las especificaciones "Muestra positiva" de SPHMC*
-- ============================================================================

SELECT 'Actualizando especificaciones Muestra positiva...' as info;

UPDATE amunet_quality_parameter_specification_config apsc
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "type": "select",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando.",
            "options": [
                {"label": "Negativa", "value": "A"},
                {"label": "Positiva", "value": "B"}
            ]
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {"label": "Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "B", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE apsc.specification_name = 'Muestra positiva'
AND apsc.id IN (
    SELECT apsc2.id FROM amunet_quality_parameter_specification_config apsc2
    JOIN amunet_quality_parameter_product_rel rel ON rel.id = apsc2.product_parameter_rel_id
    JOIN product_template pt ON pt.id = rel.product_tmpl_id
    JOIN product_product pp ON pp.product_tmpl_id = pt.id
    WHERE pp.default_code LIKE 'SPHMC%'
    AND apsc2.specification_name = 'Muestra positiva'
    AND (apsc2.evaluation_type = 'vama_multi_check' AND apsc2.text_phrase_mapping IS NULL)
);

SELECT 'Actualizadas Muestra positiva: ' || ROW_COUNT() || ' registros' as resultado;

-- ============================================================================
-- Actualizar TODAS las especificaciones "Muestra negativa" de SPHMC*
-- ============================================================================

SELECT 'Actualizando especificaciones Muestra negativa...' as info;

UPDATE amunet_quality_parameter_specification_config apsc
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "type": "select",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando.",
            "options": [
                {"label": "Negativa", "value": "A"},
                {"label": "Positiva", "value": "B"}
            ]
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {"label": "Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "B", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE apsc.specification_name = 'Muestra negativa'
AND apsc.id IN (
    SELECT apsc2.id FROM amunet_quality_parameter_specification_config apsc2
    JOIN amunet_quality_parameter_product_rel rel ON rel.id = apsc2.product_parameter_rel_id
    JOIN product_template pt ON pt.id = rel.product_tmpl_id
    JOIN product_product pp ON pp.product_tmpl_id = pt.id
    WHERE pp.default_code LIKE 'SPHMC%'
    AND apsc2.specification_name = 'Muestra negativa'
    AND (apsc2.evaluation_type = 'vama_multi_check' AND apsc2.text_phrase_mapping IS NULL)
);

SELECT 'Actualizadas Muestra negativa: ' || ROW_COUNT() || ' registros' as resultado;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Productos SPHMC* con MAVI-07 actualizados:' as info;

SELECT 
    pp.default_code as codigo,
    apsc.specification_name,
    apsc.evaluation_type,
    CASE WHEN apsc.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget,
    CASE WHEN apsc.text_phrase_mapping LIKE '%"type": "select"%' THEN 'SÍ neutro' ELSE 'NO neutro' END as paso1_neutro,
    CASE WHEN apsc.text_phrase_mapping LIKE '%Opción A:%' THEN 'CON prefijo' ELSE 'SIN prefijo' END as paso2_prefijo
FROM amunet_quality_parameter_product_rel rel
JOIN product_template pt ON pt.id = rel.product_tmpl_id
JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter ap ON ap.id = rel.parameter_id
JOIN amunet_quality_parameter_specification_config apsc ON apsc.product_parameter_rel_id = rel.id
WHERE ap.code = 'MAVI-07' 
AND pp.default_code LIKE 'SPHMC%'
ORDER BY pp.default_code, apsc.specification_name;

COMMIT;
