-- Corregir la especificacion ID 180 para "Letra"
UPDATE amunet_quality_check_parameter_specification
SET binary_prefix = 'Letra legible/Letra ilegible',
    binary_option_fail = 'Letra ilegible'
WHERE id = 180;

-- Corregir los detalles de lineas de prueba que tienen los valores incorrectos
UPDATE amunet_quality_test_line_detail
SET binary_option_pass = 'Letra legible',
    binary_option_fail = 'Letra ilegible'
WHERE binary_option_pass = 'Sin Letra'
  AND binary_option_fail = 'Con Letra';
