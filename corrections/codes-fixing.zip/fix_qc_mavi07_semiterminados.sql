-- ============================================================================
-- Script para actualizar QCs existentes de semiterminados con MAVI-07
-- Fecha: 2026-03-01
-- ============================================================================
-- QCs a actualizar:262, 284, 285, 287, 288
-- Detalles a actualizar:1243, 1287, 1292, 1301, 1305
-- ============================================================================

BEGIN;

SELECT 'Actualizando text_phrase_mapping en QCs existentes:' as info;

-- Actualizar detalle 1243 (QC262 - STBTR01)
UPDATE amunet_quality_test_line_detail
SET text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "phrase_template": "{0} con {1}.", "success_message": "Interpretación de resultados correcta.", "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id = 1243
RETURNING id, check_id, name;

-- Actualizar detalle 1287 (QC284 - STREX01)
UPDATE amunet_quality_test_line_detail
SET text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "phrase_template": "{0} con {1}.", "success_message": "Interpretación de resultados correcta.", "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id = 1287
RETURNING id, check_id, name;

-- Actualizar detalle 1292 (QC285 - STREX01)
UPDATE amunet_quality_test_line_detail
SET text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "phrase_template": "{0} con {1}.", "success_message": "Interpretación de resultados correcta.", "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id = 1292
RETURNING id, check_id, name;

-- Actualizar detalle 1301 (QC287 - STREX02)
UPDATE amunet_quality_test_line_detail
SET text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "phrase_template": "{0} con {1}.", "success_message": "Interpretación de resultados correcta.", "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id = 1301
RETURNING id, check_id, name;

-- Actualizar detalle 1305 (QC288 - STREX01)
UPDATE amunet_quality_test_line_detail
SET text_phrase_mapping = '{"positions": [{"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [{"label": "Muestra Negativa", "value": "negative"}, {"label": "Muestra Positiva", "value": "positive"}]}, {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el numeral visualizado.", "options": [{"label": "#1", "value": "result_1"}, {"label": "#2", "value": "result_2"}, {"label": "#3", "value": "result_3"}, {"label": "#4", "value": "result_4"}, {"label": "#5", "value": "result_5"}]}], "phrase_template": "{0} con {1}.", "success_message": "Interpretación de resultados correcta.", "evaluation": {"rules": [{"sample_type": "negative", "result": "result_5", "verdict": "pass", "message": "Muestra Negativa: Línea #5 visible - CUMPLE"}, {"sample_type": "negative", "result": "result_1", "verdict": "fail", "message": "Muestra Negativa: Línea #1 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_2", "verdict": "fail", "message": "Muestra Negativa: Línea #2 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_3", "verdict": "fail", "message": "Muestra Negativa: Línea #3 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "negative", "result": "result_4", "verdict": "fail", "message": "Muestra Negativa: Línea #4 visible - NO CUMPLE (esperado #5)"}, {"sample_type": "positive", "result": "result_1", "verdict": "pass", "message": "Muestra Positiva: Línea #1 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_2", "verdict": "pass", "message": "Muestra Positiva: Línea #2 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_3", "verdict": "pass", "message": "Muestra Positiva: Línea #3 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_4", "verdict": "pass", "message": "Muestra Positiva: Línea #4 visible - CUMPLE"}, {"sample_type": "positive", "result": "result_5", "verdict": "fail", "message": "Muestra Positiva: Línea #5 visible - NO CUMPLE (esperado #1-4)"}]}}',
    write_date = NOW()
WHERE id = 1305
RETURNING id, check_id, name;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - QCs actualizados:' as info;

SELECT id, check_id, name, evaluation_type,
       CASE WHEN text_phrase_mapping LIKE '%evaluation%' THEN 'SÍ tiene evaluation' ELSE 'NO tiene evaluation' END as tiene_evaluation
FROM amunet_quality_test_line_detail
WHERE id IN (1243, 1287, 1292, 1301, 1305);

COMMIT;

-- ============================================================================
-- RESUMEN
-- ============================================================================
-- QCs actualizados con reglas de evaluación MAVI-07 correctas:
-- - QC262 (detalle 1243) - STBTR01
-- - QC284 (detalle 1287) - STREX01
-- - QC285 (detalle 1292) - STREX01
-- - QC287 (detalle 1301) - STREX02
-- - QC288 (detalle 1305) - STREX01
-- ============================================================================
