-- Script SQL para corregir especificaciones MAVI-11 para producto con ID 840
-- Según documentación de semiterminados (STTCS01), las especificaciones MAVI-11 deben ser:
-- Tipo: Rango numérico (numeric_range)
-- Producto: Tapa del tubo colector, Altura:20 mm ± 2 mm
-- Producto: Tubo colector - Altura:65 mm ± 2 mm
-- Producto: Tubo colector con tapa - Altura:75 mm ± 2 mm

-- Ver especificaciones actuales configuradas en el producto
UPDATE amunet_quality_check_parameter_specification
SET 
    evaluation_type = 'numeric_range',
    min_value = 18.0,
    max_value = 22.0,
    uom_id = (SELECT id FROM uom where name = 'mm')
    acceptance_criteria = '20 mm ± 2 mm'
WHERE specification_id = (SELECT id FROM amunet_quality_check_parameter_specification WHERE name = 'Tapa del tubo colector - Altura');

-- Especificación 2: Tubo colector - Altura
UPDATE amunet_quality_check_parameter_specification
SET 
    evaluation_type = 'numeric_range',
    min_value = 63.0,
    max_value = 67.0,
    uom_id = (Select id from uom where name = 'mm')
    acceptance_criteria = '65 mm ± 2 mm'
WHERE specification_id = (SELECT id FROM amunet_quality_check_parameter_specification WHERE name = 'Tubo colector - Altura')

-- especificación 3: Tubo colector con tapa - Altura
UPDATE amunet_quality_check_parameter_specification
set 
    evaluation_type = 'numeric_range',
    min_value = 73.0,
    max_value = 77.0,
    uom_id = (Select id from uom where name = 'mm')
    acceptance_criteria = '75 mm ± 2 mm'
WHERE specification_id = (SELECT id FROM amunet_quality_check_parameter_specification WHERE name = 'Tubo colector con tapa - Altura');

-- Eliminar especificaciones incorrectas si existen
DELETE FROM amunet_quality_check_parameter_specification
WHERE product_id = 840
    AND parameter_id = (SELECT id FROM amunet_quality_check_parameter WHERE code = 'MAVI-11')
    AND name NOT IN ('Tapa del tubo colector - Altura', 'Tubo colector - Altura', 'Tubo colector con tapa - Altura');

-- Eliminar configuraciones incorrectas del producto
DELETE FROM amunet_quality_check_parameter_specification_config
WHERE specification_id IN (
    SELECT id FROM amunet_quality_check_parameter_specification 
    WHERE product_id = 840 
    AND specification_id IN (
        SELECT id FROM amunet_quality_check_parameter_specification 
        WHERE name IN ('Tapa del tubo colector - Altura', 'Tubo colector - Altura', 'Tubo colector con tapa - Altura')
    )
);

-- Verificar estructura
SELECT pp.code, pp.name, pt.name
FROM amunet_quality_check_parameter_specification_config
WHERE specification_id IN (
    SELECT id FROM amunet_quality_check_parameter_specification 
    WHERE product_id = 840
    AND name IN ('Tapa del tubo colector - Altura', 'Tubo colector - Altura', 'Tubo colector con tapa - Altura')
;

-- Mostrar resultado
DO $do$;
