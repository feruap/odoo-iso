#!/usr/bin/env python3
"""
Script para analizar productos semiterminados y comparar con documentación.
"""
import subprocess
import json
import re

# Ejecutar consulta SQL para obtener productos con parámetros de semiterminados
def run_query(query):
    result = subprocess.run(
        ['docker', 'exec', 'odoo-docker-web-db-1', 'psql', '-U', 'odoo', '-d', 'amunet_local', '-t', '-A', '-F', '|', '-c', query],
        capture_output=True,
        text=True,
        encoding='utf-8'
    )
    return result.stdout.strip()

# Obtener productos con configuraciones de semiterminados
query_products = """
SELECT DISTINCT pt.id, pt.name->>'es_MX' as name
FROM product_template pt
WHERE EXISTS (
    SELECT 1 FROM amunet_quality_parameter_specification_config qpsc
    JOIN amunet_quality_check_parameter qcp ON qcp.id = qpsc.parameter_id
    WHERE qpsc.product_tmpl_id = pt.id
    AND qcp.code IN ('MAVI-04', 'MAVI-11', 'VAMA-044', 'VAMA-096', 'VAMA-023', 'VAMA-094', 'VAMA-095', 'VAMA-052', 'VAMA-093', 'VAMA-098', 'VAMA-099')
)
ORDER BY pt.name->>'es_MX';
"""

print("=== PRODUCTOS SEMITERMINADOS EN BASE DE DATOS ===\n")
products_output = run_query(query_products)

if products_output:
    for line in products_output.split('\n'):
        if line.strip():
            parts = line.split('|')
            if len(parts) >= 2:
                print(f"ID: {parts[0]}, Nombre: {parts[1]}")

# Obtener configuraciones detalladas por producto
print("\n\n=== CONFIGURACIONES DETALLADAS ===\n")

query_configs = """
SELECT 
    pt.id as product_id,
    pt.name->>'es_MX' as producto,
    qcp.code as parametro,
    qpsc.id as config_id,
    qpsc.specification_name,
    qpsc.evaluation_type,
    qpsc.min_value,
    qpsc.max_value,
    qpsc.acceptance_criteria,
    qpsc.text_phrase_mapping
FROM product_template pt
JOIN amunet_quality_parameter_specification_config qpsc ON qpsc.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter qcp ON qcp.id = qpsc.parameter_id
WHERE qcp.code IN ('MAVI-04', 'MAVI-11', 'VAMA-044', 'VAMA-096', 'VAMA-023', 'VAMA-094', 'VAMA-095', 'VAMA-052', 'VAMA-093', 'VAMA-098', 'VAMA-099')
ORDER BY pt.name->>'es_MX', qcp.code, qpsc.specification_name;
"""

configs_output = run_query(query_configs)

# Guardar resultado en archivo
with open('corrections/semiterminados_db_configs.txt', 'w', encoding='utf-8') as f:
    f.write("PRODUCTO|PARAMETRO|CONFIG_ID|SPEC_NAME|EVAL_TYPE|MIN|MAX|ACCEPTANCE|TEXT_MAPPING\n")
    f.write(configs_output)

print("Configuraciones guardadas en corrections/semiterminados_db_configs.txt")
