-- ============================================================================
-- Script de corrección MAVI-07 para SPHMC01 (Hojas Maestras) - v6
-- Fecha: 2026-03-02
-- ============================================================================
-- Cambios solicitados:
-- 1. Quitar colores verde/rojo del Paso1 (Tipo de Muestra) - usar botones neutrales
-- 2. Quitar prefijo "Opción A/B/C" del Paso2 - mostrar solo la descripción
-- ============================================================================

BEGIN;

-- ============================================================================
-- Actualizar configuración plantilla para SPHMC01
-- ============================================================================

SELECT 'Actualizando configuración MAVI-07 para SPHMC01 (v6)...' as info;

-- Actualizar "Muestra positiva" (config_id:78308)
UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "type": "select",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando.",
            "options": [
                {"label": "Negativa", "value": "A"},
                {"label": "Positiva", "value": "B"}
            ]
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {"label": "Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "B", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 78308;

-- Actualizar "Muestra negativa" (config_id:78373)
UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "type": "select",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando.",
            "options": [
                {"label": "Negativa", "value": "A"},
                {"label": "Positiva", "value": "B"}
            ]
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {"label": "Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "B", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 78373;

-- ============================================================================
-- Actualizar detalles del QC316
-- ============================================================================

SELECT 'Actualizando detalles del QC316...' as info;

-- Actualizar detalle "Muestra positiva" (id:1479)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "type": "select",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando.",
            "options": [
                {"label": "Negativa", "value": "A"},
                {"label": "Positiva", "value": "B"}
            ]
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {"label": "Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "B", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 1479;

-- Actualizar detalle "Muestra negativa" (id:1480)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "type": "select",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando.",
            "options": [
                {"label": "Negativa", "value": "A"},
                {"label": "Positiva", "value": "B"}
            ]
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {"label": "Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "B", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 1480;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Solo SPHMC01 tiene reglas sample_type:' as info;

SELECT 
    pp.default_code,
    apsc.specification_name,
    CASE WHEN apsc.text_phrase_mapping LIKE '%"type": "select"%' THEN 'SÍ select neutro' ELSE 'NO select' END as paso1_neutro,
    CASE WHEN apsc.text_phrase_mapping LIKE '%Opción A:%' THEN 'SÍ tiene prefijo' ELSE 'SIN prefijo' END as paso2_prefijo
FROM amunet_quality_parameter_product_rel rel
JOIN product_template pt ON pt.id = rel.product_tmpl_id
JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter ap ON ap.id = rel.parameter_id
JOIN amunet_quality_parameter_specification_config apsc ON apsc.product_parameter_rel_id = rel.id
WHERE ap.code = 'MAVI-07' 
AND pp.default_code = 'SPHMC01';

COMMIT;
