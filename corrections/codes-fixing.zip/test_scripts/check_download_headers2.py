import requests

url = 'http://localhost:8069'
db = 'amunet_local'
username = 'admin'
password = 'admin'

session = requests.Session()
login_data = {'jsonrpc': '2.0', 'method': 'call', 'params': {'db': db, 'login': username, 'password': password}}
session.post(f"{url}/web/session/authenticate", json=login_data)

# To avoid CSRF error for /web/content (POST), we can just use GET!
params = {
    "model": "amunet.equipment.calibration",
    "id": 5,
    "field": "certificate_file",
    "filename_field": "CERMP-001 AGUA TRIDESTILADA.pdf",
    "filename": "CERMP-001 AGUA TRIDESTILADA.pdf",
    "download": "true"
}

resp = session.get(f"{url}/web/content", params=params)
print("Auth:", resp.status_code)
print("Headers:", resp.headers)
print("Text preview:", resp.text[:200])
