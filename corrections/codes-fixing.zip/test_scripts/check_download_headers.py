import xmlrpc.client
import requests

url = 'http://localhost:8069'
db = 'amunet_local'
username = 'admin'
password = 'admin'

session = requests.Session()
login_data = {
    'jsonrpc': '2.0',
    'method': 'call',
    'params': {
        'db': db,
        'login': username,
        'password': password
    }
}
resp = session.post(f"{url}/web/session/authenticate", json=login_data)
print("Auth:", resp.status_code)

payload = {
    "csrf_token": session.cookies.get('csrf_token', ''),
    "model": "amunet.equipment.calibration",
    "id": 5, # ID 5 is the newest one I saw in my query
    "field": "certificate_file",
    "filename_field": "CERMP-001 AGUA TRIDESTILADA.pdf",
    "filename": "CERMP-001 AGUA TRIDESTILADA.pdf",
    "download": "true"
}

resp2 = session.post(f"{url}/web/content", data=payload)
print("Headers:", resp2.headers)
