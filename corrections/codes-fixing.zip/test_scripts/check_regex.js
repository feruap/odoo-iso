const DISPOSITION_TYPE_REGEXP =
  /^([!#$%&'*+.0-9A-Z^_`a-z|~-]+)[\x09\x20]*(?:$|;)/;
const PARAM_REGEXP =
  /;[\x09\x20]*([!#$%&'*+.0-9A-Z^_`a-z|~-]+)[\x09\x20]*=[\x09\x20]*("(?:[\x20!\x23-\x5b\x5d-\x7e\x80-\xff]|\\[\x20-\x7e])*"|[!#$%&'*+.0-9A-Z^_`a-z|~-]+)[\x09\x20]*/g;
const QESC_REGEXP = /\\([\u0000-\u007f])/g;

function parse(string) {
  let match = DISPOSITION_TYPE_REGEXP.exec(string);
  if (!match) {
    throw new TypeError("invalid type format");
  }
  let index = match[0].length;
  const type = match[1].toLowerCase();
  let key;
  const names = [];
  const params = {};
  let value;

  index = PARAM_REGEXP.lastIndex =
    match[0].substr(-1) === ";" ? index - 1 : index;

  while ((match = PARAM_REGEXP.exec(string))) {
    if (match.index !== index) {
      throw new TypeError("invalid parameter format at index " + index);
    }
    index += match[0].length;
    key = match[1].toLowerCase();
    value = match[2];

    if (value[0] === '"') {
      value = value.substr(1, value.length - 2).replace(QESC_REGEXP, "$1");
    }
    params[key] = value;
  }
  return params;
}

try {
  const header = 'attachment; filename="CERMP-001 AGUA TRIDESTILADA.pdf"';
  console.log(parse(header));
} catch (e) {
  console.log("Error:", e.message);
}
