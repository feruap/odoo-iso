import xmlrpc.client

url = 'http://localhost:8069'
db = 'amunet_local'
username = 'admin'
password = 'admin'

common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
uid = common.authenticate(db, username, password, {})

models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
atts = models.execute_kw(db, uid, password, 'ir.attachment', 'search_read', [[('res_model', '=', 'amunet.equipment.calibration')]], {'fields': ['id', 'name', 'res_model', 'res_id', 'store_fname']})

for a in atts:
    print(a)
