import xmlrpc.client

url = 'http://localhost:8069'
db = 'amunet_local'
username = 'admin'
password = 'admin'

common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
uid = common.authenticate(db, username, password, {})

models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
views = models.execute_kw(db, uid, password, 'ir.ui.view', 'search_read', [[('model', '=', 'amunet.equipment.calibration')]], {'fields': ['name', 'arch']})

for v in views:
    print(f"--- View: {v['name']} ---")
    print(v['arch'])
