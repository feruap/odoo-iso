import xmlrpc.client
import sys

url = 'http://localhost:8069'
db = 'amunet_local'
username = 'admin'
password = 'admin'

try:
    common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
    uid = common.authenticate(db, username, password, {})

    models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
    module_ids = models.execute_kw(db, uid, password, 'ir.module.module', 'search', [[('name', '=', 'amunet_equipment_calibration')]])
    if module_ids:
        print(f"Upgrading module ID {module_ids}...")
        res = models.execute_kw(db, uid, password, 'ir.module.module', 'button_immediate_upgrade', [module_ids])
        print("Upgrade result:", res)
    else:
        print("Module not found.")
except Exception as e:
    print("Error:", e)
