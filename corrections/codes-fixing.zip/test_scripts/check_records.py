import xmlrpc.client

url = 'http://localhost:8069'
db = 'amunet_local'
username = 'admin'
password = 'admin'

common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
uid = common.authenticate(db, username, password, {})

models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
records = models.execute_kw(db, uid, password, 'amunet.equipment.calibration', 'search_read', [[]], {'fields': ['id', 'lab_name', 'certificate_filename']})

for r in records:
    print(r)
