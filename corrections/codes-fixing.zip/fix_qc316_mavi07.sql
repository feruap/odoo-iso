-- ============================================================================
-- Script de actualización del QC316 para SPHMC01 con MAVI-07
-- Fecha: 2026-03-02
-- ============================================================================

BEGIN;

-- ============================================================================
-- Actualizar detalles del QC316 con la nueva configuración MAVI-07
-- ============================================================================

SELECT 'Actualizando detalles del QC316 para SPHMC01...' as info;

-- Actualizar detalle "Muestra positiva" (id:1479)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'mavi_07',
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "type": "select",
                "label": "Resultado Observado",
                "instruction": "Seleccione el resultado visualizado en la muestra POSITIVA.",
                "options": [
                    {
                        "label": "Opción A: Visualización sólo de la línea control patrón #5",
                        "value": "option_a"
                    },
                    {
                        "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                        "value": "option_b"
                    },
                    {
                        "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                        "value": "option_c"
                    }
                ]
            }
        ],
        "evaluation": {
            "rules": [
                {
                    "result": "option_a",
                    "verdict": "pass",
                    "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"
                },
                {
                    "result": "option_b",
                    "verdict": "fail",
                    "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE (esperado sólo línea control #5)"
                },
                {
                    "result": "option_c",
                    "verdict": "fail",
                    "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"
                }
            ]
        }
    }',
    write_date = NOW()
WHERE id = 1479;

-- Actualizar detalle "Muestra negativa" (id:1480)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'mavi_07',
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "type": "select",
                "label": "Resultado Observado",
                "instruction": "Seleccione el resultado visualizado en la muestra NEGATIVA.",
                "options": [
                    {
                        "label": "Opción A: Visualización sólo de la línea control patrón #5",
                        "value": "option_a"
                    },
                    {
                        "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                        "value": "option_b"
                    },
                    {
                        "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                        "value": "option_c"
                    }
                ]
            }
        ],
        "evaluation": {
            "rules": [
                {
                    "result": "option_a",
                    "verdict": "fail",
                    "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE (esperado línea control y línea de prueba #4 al #1)"
                },
                {
                    "result": "option_b",
                    "verdict": "pass",
                    "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"
                },
                {
                    "result": "option_c",
                    "verdict": "fail",
                    "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"
                }
            ]
        }
    }',
    write_date = NOW()
WHERE id = 1480;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Detalles actualizados:' as info;

SELECT 
    qtld.id,
    qtld.name,
    qtld.evaluation_type,
    CASE WHEN qtld.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_test_line_detail qtld
WHERE qtld.id IN (1479, 1480);

COMMIT;
