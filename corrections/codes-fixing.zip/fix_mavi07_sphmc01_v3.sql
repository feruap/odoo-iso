-- ============================================================================
-- Script de corrección MAVI-07 para SPHMC01 (Hojas Maestras) - CORREGIDO
-- Fecha: 2026-03-02
-- ============================================================================
-- Usando el widget vama_multi_check correcto para Hojas Maestras
-- Estructura:
-- - Paso1: Tipo de Muestra (botones Negativa/Positiva)
-- - Paso2: Resultado Observado (dropdown con 3 opciones A, B, C)
--
-- Criterios de evaluación:
-- - Muestra positiva: Opción A = pass (Visualización sólo de la línea control patrón #5)
-- - Muestra negativa: Opción B = pass (Visualización de línea control y línea de prueba #4 al #1)
-- ============================================================================

BEGIN;

-- ============================================================================
-- Actualizar configuración plantilla para SPHMC01
-- ============================================================================

SELECT 'Actualizando configuración MAVI-07 para SPHMC01 con vama_multi_check...' as info;

-- Actualizar "Muestra positiva" (config_id:78308)
UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "Positiva", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "Positiva", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "Positiva", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "Negativa", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 78308;

-- Actualizar "Muestra negativa" (config_id:78373)
UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "Positiva", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "Positiva", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "Positiva", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "Negativa", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 78373;

-- ============================================================================
-- Actualizar detalles del QC316
-- ============================================================================

SELECT 'Actualizando detalles del QC316...' as info;

-- Actualizar detalle "Muestra positiva" (id:1479)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "Positiva", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "Positiva", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "Positiva", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "Negativa", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 1479;

-- Actualizar detalle "Muestra negativa" (id:1480)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "Positiva", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "Positiva", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "Positiva", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "Negativa", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "Negativa", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 1480;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Configuración actualizada:' as info;

SELECT 
    apsc.id,
    apsc.specification_name,
    apsc.evaluation_type,
    CASE WHEN apsc.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_parameter_specification_config apsc
WHERE apsc.id IN (78308, 78373);

SELECT 'Verificación - Detalles QC316 actualizados:' as info;

SELECT 
    qtld.id,
    qtld.name,
    qtld.evaluation_type,
    CASE WHEN qtld.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_test_line_detail qtld
WHERE qtld.id IN (1479, 1480);

COMMIT;
