-- ============================================================================
-- Script de corrección para productos STVIA05, STVIR01, STVIR02
-- Fecha: 2026-03-01
-- ============================================================================
-- Problemas identificados:
-- 1. VAMA-096 no debería estar en estos productos (solo MA-096)
-- 2. MAVI-11 tiene tipo de evaluación incorrecto (mavi_11_height en lugar de numeric_range)
-- ============================================================================
-- Productos afectados:
--   - STVIA05 (product_template_id: 992) - Vial 5 ml para buffer
--   - STVIR01 (product_template_id: 993) - Vial 5 ml para buffer con recolector
--   - STVIR02 (product_template_id: 994) - Vial 5 ml para buffer sin recolector
-- ============================================================================

BEGIN;

-- ============================================================================
-- PARTE 1: Eliminar VAMA-096 de los productos STVIA05, STVIR01, STVIR02
-- ============================================================================
-- VAMA-096 (parameter_id: 70) no debe estar en estos productos
-- Solo debe mantenerse MA-096 (parameter_id: 144)

-- Verificar antes de eliminar
SELECT 'Registros VAMA-096 a eliminar:' as info;
SELECT ppr.id, ppr.product_tmpl_id, pt.name as product_name, pp.default_code, 
       ppr.parameter_id, qp.code as parameter_code, qp.name as parameter_name
FROM amunet_quality_parameter_product_rel ppr
JOIN product_template pt ON pt.id = ppr.product_tmpl_id
LEFT JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter qp ON qp.id = ppr.parameter_id
WHERE ppr.id IN (3067, 3068, 3069);

-- Eliminar las relaciones producto-parámetro de VAMA-096
-- Esto eliminará automáticamente las configuraciones asociadas (ON DELETE CASCADE)
DELETE FROM amunet_quality_parameter_product_rel 
WHERE id IN (3067, 3068, 3069)
RETURNING id, product_tmpl_id, parameter_id;

-- ============================================================================
-- PARTE 2: Corregir tipo de evaluación de MAVI-11 a 'numeric_range'
-- ============================================================================
-- Según documentación, MAVI-11 debe usar "Campo numérico decimal" (numeric_range)
-- Actualmente tiene 'mavi_11_height' que es incorrecto

-- Verificar configuraciones activas de MAVI-11 antes de actualizar
SELECT 'Configuraciones MAVI-11 activas antes del cambio:' as info;
SELECT psc.id, psc.product_tmpl_id, pt.name as product_name, pp.default_code,
       psc.specification_name, psc.evaluation_type
FROM amunet_quality_parameter_specification_config psc
JOIN product_template pt ON pt.id = psc.product_tmpl_id
LEFT JOIN product_product pp ON pp.product_tmpl_id = pt.id
WHERE psc.id IN (78108, 78110, 78111, 78116, 78117, 78118, 78123, 78124, 78125)
ORDER BY psc.product_tmpl_id, psc.id;

-- Actualizar tipo de evaluación de MAVI-11 de 'mavi_11_height' a 'numeric_range'
UPDATE amunet_quality_parameter_specification_config
SET evaluation_type = 'numeric_range',
    write_date = NOW()
WHERE id IN (78108, 78110, 78111, 78116, 78117, 78118, 78123, 78124, 78125)
  AND evaluation_type = 'mavi_11_height'
RETURNING id, product_tmpl_id, specification_name, evaluation_type;

-- ============================================================================
-- VERIFICACIÓN FINAL
-- ============================================================================

-- Verificar que VAMA-096 ya no está en estos productos
SELECT 'Verificación: VAMA-096 no debe aparecer en estos productos:' as info;
SELECT ppr.id, ppr.product_tmpl_id, pt.name as product_name, pp.default_code, 
       ppr.parameter_id, qp.code as parameter_code
FROM amunet_quality_parameter_product_rel ppr
JOIN product_template pt ON pt.id = ppr.product_tmpl_id
LEFT JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter qp ON qp.id = ppr.parameter_id
WHERE ppr.product_tmpl_id IN (992, 993, 994)
  AND ppr.parameter_id = 70;

-- Verificar que MA-096 sigue presente
SELECT 'Verificación: MA-096 debe seguir presente en estos productos:' as info;
SELECT ppr.id, ppr.product_tmpl_id, pt.name as product_name, pp.default_code, 
       ppr.parameter_id, qp.code as parameter_code
FROM amunet_quality_parameter_product_rel ppr
JOIN product_template pt ON pt.id = ppr.product_tmpl_id
LEFT JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter qp ON qp.id = ppr.parameter_id
WHERE ppr.product_tmpl_id IN (992, 993, 994)
  AND ppr.parameter_id = 144;

-- Verificar configuraciones MAVI-11 actualizadas
SELECT 'Verificación: MAVI-11 debe tener evaluation_type = numeric_range:' as info;
SELECT psc.id, psc.product_tmpl_id, pt.name as product_name, pp.default_code,
       psc.specification_name, psc.evaluation_type, psc.active
FROM amunet_quality_parameter_specification_config psc
JOIN product_template pt ON pt.id = psc.product_tmpl_id
LEFT JOIN product_product pp ON pp.product_tmpl_id = pt.id
WHERE psc.product_tmpl_id IN (992, 993, 994)
  AND psc.parameter_id = 64
  AND psc.active = true
ORDER BY psc.product_tmpl_id, psc.id;

COMMIT;

-- ============================================================================
-- RESUMEN DE CAMBIOS
-- ============================================================================
-- 1. Eliminada determinación VAMA-096 de:
--    - STVIA05 (product_template_id: 992) - rel_id: 3067
--    - STVIR01 (product_template_id: 993) - rel_id: 3068
--    - STVIR02 (product_template_id: 994) - rel_id: 3069
--
-- 2. Actualizado tipo de evaluación de MAVI-11 de 'mavi_11_height' a 'numeric_range':
--    - STVIA05 (992): config_ids 78108, 78110, 78111
--    - STVIR01 (993): config_ids 78116, 78117, 78118
--    - STVIR02 (994): config_ids 78123, 78124, 78125
--
-- 3. MA-096 se mantiene sin cambios en los 3 productos (config_ids: 78112, 78119, 78126)
-- ============================================================================
