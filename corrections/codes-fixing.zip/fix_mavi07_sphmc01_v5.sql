-- ============================================================================
-- Script de corrección MAVI-07 para SPHMC01 (Hojas Maestras) - v5 CORREGIDO
-- Fecha: 2026-03-02
-- ============================================================================
-- Usando el widget vama_multi_check correcto para Hojas Maestras
-- 
-- IMPORTANTE: El Paso1 guarda valores 'A' o 'B', no los labels
-- - A = Negativa
-- - B = Positiva
--
-- La evaluación compara:
-- - sample_type: valor del índice 0 ('A' o 'B')
-- - result: valor del índice 1 ('option_a', 'option_b', 'option_c')
--
-- Especificación "Muestra positiva":
-- - B (Positiva) + option_a = PASS
--
-- Especificación "Muestra negativa":
-- - A (Negativa) + option_b = PASS
-- ============================================================================

BEGIN;

-- ============================================================================
-- Actualizar configuración plantilla para SPHMC01
-- ============================================================================

SELECT 'Actualizando configuración MAVI-07 para SPHMC01...' as info;

-- Actualizar "Muestra positiva" (config_id:78308)
-- PASS cuando: Paso1=B (Positiva) + Paso2=option_a
UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "B", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE (esperado sólo línea control #5)"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra (Negativa) no coincide con especificación (Positiva) - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra (Negativa) no coincide con especificación (Positiva) - NO CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra (Negativa) no coincide con especificación (Positiva) - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 78308;

-- Actualizar "Muestra negativa" (config_id:78373)
-- PASS cuando: Paso1=A (Negativa) + Paso2=option_b
UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE (esperado línea control y línea de prueba)"},
            {"sample_type": "A", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "B", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra (Positiva) no coincide con especificación (Negativa) - NO CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra (Positiva) no coincide con especificación (Negativa) - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra (Positiva) no coincide con especificación (Negativa) - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 78373;

-- ============================================================================
-- Actualizar detalles del QC316
-- ============================================================================

SELECT 'Actualizando detalles del QC316...' as info;

-- Actualizar detalle "Muestra positiva" (id:1479)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "B", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 1479;

-- Actualizar detalle "Muestra negativa" (id:1480)
UPDATE amunet_quality_test_line_detail 
SET 
    evaluation_type = 'vama_multi_check',
    text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "A": "Negativa",
            "B": "Positiva",
            "context": "Muestra {value}",
            "label": "1. Tipo de Muestra",
            "instruction": "Indique qué tipo de muestra se está evaluando."
        },
        {
            "index": 1,
            "type": "select",
            "label": "2. Resultado Observado",
            "instruction": "Seleccione el resultado visualizado.",
            "options": [
                {
                    "label": "Opción A: Visualización sólo de la línea control patrón #5",
                    "value": "option_a"
                },
                {
                    "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                    "value": "option_b"
                },
                {
                    "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                    "value": "option_c"
                }
            ]
        }
    ],
    "phrase_template": "{0}: {1}",
    "evaluation": {
        "rules": [
            {"sample_type": "A", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE"},
            {"sample_type": "A", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "A", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "B", "result": "option_a", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_b", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"},
            {"sample_type": "B", "result": "option_c", "verdict": "fail", "message": "Tipo de muestra no coincide con especificación - NO CUMPLE"}
        ]
    }
}',
    write_date = NOW()
WHERE id = 1480;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Configuración actualizada:' as info;

SELECT 
    apsc.id,
    apsc.specification_name,
    apsc.evaluation_type,
    CASE WHEN apsc.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_parameter_specification_config apsc
WHERE apsc.id IN (78308, 78373);

SELECT 'Verificación - Detalles QC316 actualizados:' as info;

SELECT 
    qtld.id,
    qtld.name,
    qtld.evaluation_type,
    CASE WHEN qtld.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_test_line_detail qtld
WHERE qtld.id IN (1479, 1480);

COMMIT;
