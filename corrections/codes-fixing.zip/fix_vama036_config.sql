-- ============================================================================
-- Configuración de VAMA-036 para Material Impreso (Tarjetas de color)
-- ============================================================================
-- 
-- Este script configura la determinación VAMA-036 con las especificaciones:
-- 1. Nombre de la tarjeta
-- 2. Instrucciones de uso
-- 3. Interpretación de resultados
--
-- Criterios de aceptación:
-- - El nombre de la tarjeta coincide
-- - Las instrucciones de uso coinciden
-- - La interpretación de resultados coincide
--
-- Opciones: Coincide / No coincide / No aplica
--
-- Lógica:
-- - ESCENARIO1 (Todo cumple): Si NINGUNA selección es "No coincide"
-- - ESCENARIO2 (Uno o más fallos): Si AL MENOS UNA selección es "No coincide"
-- ============================================================================

-- ============================================================================
-- PASO1: Actualizar las especificaciones en la configuración del producto839
-- (Tarjeta de color hemoglobina) - rel_id3029
-- ============================================================================

-- 1.1 Actualizar "Nombre de la tarjeta"
UPDATE amunet_quality_parameter_specification_config 
SET 
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "label": "Nombre de la tarjeta",
                "type": "ternary",
                "A": "Coincide",
                "B": "No coincide",
                "N": "No aplica",
                "pass_value": "A",
                "na_value": "N",
                "error_msg": "El nombre de la tarjeta no coincide."
            }
        ],
        "success_message": "La información presentada es correcta y coincide con la prueba indicada en la orden de fabricación o lista de prueba oficial. Es clara y precisa, permitiendo la óptima ejecución y/o interpretación de la prueba.\n\nLas imágenes y símbolos son representativos a la prueba a la que pertenece.",
        "error_prefix": "La información presenta discrepancias. Fallos detectados:",
        "dynamic_error": true
    }',
    acceptance_criteria = 'El nombre de la tarjeta coincide',
    ternary_option_yes = 'Coincide',
    ternary_option_no = 'No coincide',
    ternary_option_na = 'No aplica'
WHERE id = 71241;

-- 1.2 Actualizar "Instrucciones de uso"
UPDATE amunet_quality_parameter_specification_config 
SET 
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "label": "Instrucciones de uso",
                "type": "ternary",
                "A": "Coinciden",
                "B": "No coinciden",
                "N": "No aplica",
                "pass_value": "A",
                "na_value": "N",
                "error_msg": "Las instrucciones de uso no coinciden."
            }
        ],
        "success_message": "La información presentada es correcta y coincide con la prueba indicada en la orden de fabricación o lista de prueba oficial. Es clara y precisa, permitiendo la óptima ejecución y/o interpretación de la prueba.\n\nLas imágenes y símbolos son representativos a la prueba a la que pertenece.",
        "error_prefix": "La información presenta discrepancias. Fallos detectados:",
        "dynamic_error": true
    }',
    acceptance_criteria = 'Las instrucciones de uso coinciden',
    ternary_option_yes = 'Coinciden',
    ternary_option_no = 'No coinciden',
    ternary_option_na = 'No aplica'
WHERE id = 71242;

-- 1.3 Actualizar "Interpretación de resultados"
UPDATE amunet_quality_parameter_specification_config 
SET 
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "label": "Interpretación de resultados",
                "type": "ternary",
                "A": "Coincide",
                "B": "No coincide",
                "N": "No aplica",
                "pass_value": "A",
                "na_value": "N",
                "error_msg": "La interpretación de resultados no coincide."
            }
        ],
        "success_message": "La información presentada es correcta y coincide con la prueba indicada en la orden de fabricación o lista de prueba oficial. Es clara y precisa, permitiendo la óptima ejecución y/o interpretación de la prueba.\n\nLas imágenes y símbolos son representativos a la prueba a la que pertenece.",
        "error_prefix": "La información presenta discrepancias. Fallos detectados:",
        "dynamic_error": true
    }',
    acceptance_criteria = 'La interpretación de resultados coincide',
    ternary_option_yes = 'Coincide',
    ternary_option_no = 'No coincide',
    ternary_option_na = 'No aplica'
WHERE id = 71243;

-- ============================================================================
-- PASO2: Verificar la configuración
-- ============================================================================

SELECT 
    cfg.id,
    cfg.specification_name,
    cfg.evaluation_type,
    cfg.acceptance_criteria,
    cfg.ternary_option_yes,
    cfg.ternary_option_no,
    cfg.ternary_option_na,
    CASE 
        WHEN cfg.text_phrase_mapping IS NOT NULL THEN 'CONFIGURADO'
        ELSE 'SIN CONFIGURAR'
    END as mapping_status
FROM amunet_quality_parameter_specification_config cfg
WHERE cfg.product_parameter_rel_id = 3029
ORDER BY cfg.id;

-- ============================================================================
-- NOTA: Para aplicar esta configuración a otros productos de Tarjetas de color,
-- se necesitan los IDs de configuración correspondientes.
-- ============================================================================
