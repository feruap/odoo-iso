-- Consolidar las 3 especificaciones VAMA-036 en un solo registro
-- Esto une las 3 positions en un solo text_phrase_mapping

-- 1. Primero, obtener el text_phrase_mapping completo de cada config
-- y crear uno consolidado con las 3 positions

-- Actualizar el primer detalle (669) con las 3 especificaciones consolidadas
UPDATE amunet_quality_test_line_detail
SET text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "label": "Nombre de la tarjeta",
            "type": "ternary",
            "A": "Coincide",
            "B": "No coincide",
            "N": "No aplica",
            "pass_value": "A",
            "na_value": "N",
            "error_msg": "El nombre de la tarjeta no coincide."
        },
        {
            "index": 1,
            "label": "Instrucciones de uso",
            "type": "ternary",
            "A": "Coincide",
            "B": "No coincide",
            "N": "No aplica",
            "pass_value": "A",
            "na_value": "N",
            "error_msg": "Las instrucciones de uso no coinciden."
        },
        {
            "index": 2,
            "label": "Interpretación de resultados",
            "type": "ternary",
            "A": "Coincide",
            "B": "No coincide",
            "N": "No aplica",
            "pass_value": "A",
            "na_value": "N",
            "error_msg": "La interpretación de resultados no coincide."
        }
    ],
    "success_message": "La información presentada es correcta, el material cumple con las especificaciones de la tarjeta de color.",
    "error_prefix": "La información presenta discrepancias. Fallos detectados:",
    "dynamic_error": true
}'
WHERE id = 669;

-- 2. Actualizar la configuración 71241 con el mapping consolidado
UPDATE amunet_quality_parameter_specification_config
SET text_phrase_mapping = '{
    "positions": [
        {
            "index": 0,
            "label": "Nombre de la tarjeta",
            "type": "ternary",
            "A": "Coincide",
            "B": "No coincide",
            "N": "No aplica",
            "pass_value": "A",
            "na_value": "N",
            "error_msg": "El nombre de la tarjeta no coincide."
        },
        {
            "index": 1,
            "label": "Instrucciones de uso",
            "type": "ternary",
            "A": "Coincide",
            "B": "No coincide",
            "N": "No aplica",
            "pass_value": "A",
            "na_value": "N",
            "error_msg": "Las instrucciones de uso no coinciden."
        },
        {
            "index": 2,
            "label": "Interpretación de resultados",
            "type": "ternary",
            "A": "Coincide",
            "B": "No coincide",
            "N": "No aplica",
            "pass_value": "A",
            "na_value": "N",
            "error_msg": "La interpretación de resultados no coincide."
        }
    ],
    "success_message": "La información presentada es correcta, el material cumple con las especificaciones de la tarjeta de color.",
    "error_prefix": "La información presenta discrepancias. Fallos detectados:",
    "dynamic_error": true
}'
WHERE id = 71241;

-- 3. Desactivar los otros dos detalles (670, 671) para que no se muestren
-- En lugar de eliminarlos, los marcamos como inactivos o los ocultamos
-- Actualizamos specification_config_id a NULL para que no tengan configuración
UPDATE amunet_quality_test_line_detail
SET specification_config_id = NULL,
    text_phrase_mapping = NULL
WHERE id IN (670, 671);

-- Nota: Si se necesitan mantener los registros por integridad, 
-- se pueden marcar como activo = false si existe ese campo
-- o simplemente dejarlos sin configuración
