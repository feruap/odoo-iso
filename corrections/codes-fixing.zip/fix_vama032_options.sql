-- =====================================================
-- Fix VAMA-032: Configurar expected_options y obtained_options
-- =====================================================

-- 1. Verificar especificaciones con evaluation_type = 'expected_vs_obtained'
SELECT 
    ps.id as spec_id,
    ps.name as spec_name,
    ps.evaluation_type,
    ps.expected_options,
    ps.obtained_options,
    pt.name as product_name
FROM amunet_quality_check_parameter_specification ps
JOIN amunet_quality_parameter_product_rel rel ON ps.id = rel.specification_id
JOIN product_template pt ON rel.product_id = pt.id
WHERE ps.evaluation_type = 'expected_vs_obtained';

-- 2. Actualizar especificaciones que no tienen opciones configuradas
UPDATE amunet_quality_check_parameter_specification
SET 
    expected_options = 'Muestra Negativa,Muestra Positiva',
    obtained_options = 'Negativo,Positivo'
WHERE evaluation_type = 'expected_vs_obtained'
AND (expected_options IS NULL OR expected_options = '');

-- 3. Actualizar detalles existentes que no tienen opciones
UPDATE amunet_quality_test_line_detail d
SET 
    expected_options = 'Muestra Negativa,Muestra Positiva',
    obtained_options = 'Negativo,Positivo'
FROM amunet_quality_test_line tl
WHERE d.test_line_id = tl.id
AND d.evaluation_type = 'expected_vs_obtained'
AND (d.expected_options IS NULL OR d.expected_options = '');

-- 4. Verificar los cambios
SELECT 
    d.id as detail_id,
    d.name as detail_name,
    d.evaluation_type,
    d.expected_options,
    d.obtained_options,
    tl.name as line_name
FROM amunet_quality_test_line_detail d
JOIN amunet_quality_test_line tl ON d.test_line_id = tl.id
WHERE d.evaluation_type = 'expected_vs_obtained';
