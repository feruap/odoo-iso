-- ============================================================================
-- Script de corrección MAVI-07 para SPHMC01 (Hojas Maestras)
-- Fecha: 2026-03-02
-- ============================================================================
-- Problema identificado:
-- SPHMC01 tiene2 especificaciones separadas para MAVI-07:
-- - "Muestra positiva" (config_id:78308)
-- - "Muestra negativa" (config_id:78373)
-- Ambas tienen evaluation_type = vama_multi_check pero SIN text_phrase_mapping
--
-- Estructura requerida del widget MAVI-07:
-- - Paso1: Tipo de muestra (definido por el nombre de la especificación)
-- - Paso2: Tres opciones de resultado:
--   - Opción A: Visualización sólo de la línea control patrón #5
--   - Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1
--   - Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba
--
-- Criterios de evaluación:
-- - Muestra positiva: Opción A = pass (Visualización sólo de la línea control patrón #5)
-- - Muestra negativa: Opción B = pass (Visualización de línea control y línea de prueba #4 al #1)
-- ============================================================================

BEGIN;

-- ============================================================================
-- Paso1: Actualizar especificación "Muestra positiva" (config_id:78308)
-- ============================================================================

SELECT 'Actualizando especificación Muestra positiva para SPHMC01...' as info;

UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'mavi_07',
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "type": "select",
                "label": "Resultado Observado",
                "instruction": "Seleccione el resultado visualizado en la muestra POSITIVA.",
                "options": [
                    {
                        "label": "Opción A: Visualización sólo de la línea control patrón #5",
                        "value": "option_a"
                    },
                    {
                        "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                        "value": "option_b"
                    },
                    {
                        "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                        "value": "option_c"
                    }
                ]
            }
        ],
        "evaluation": {
            "rules": [
                {
                    "result": "option_a",
                    "verdict": "pass",
                    "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"
                },
                {
                    "result": "option_b",
                    "verdict": "fail",
                    "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE (esperado sólo línea control #5)"
                },
                {
                    "result": "option_c",
                    "verdict": "fail",
                    "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"
                }
            ]
        }
    }',
    write_date = NOW()
WHERE id = 78308;

-- ============================================================================
-- Paso2: Actualizar especificación "Muestra negativa" (config_id:78373)
-- ============================================================================

SELECT 'Actualizando especificación Muestra negativa para SPHMC01...' as info;

UPDATE amunet_quality_parameter_specification_config 
SET 
    evaluation_type = 'mavi_07',
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "type": "select",
                "label": "Resultado Observado",
                "instruction": "Seleccione el resultado visualizado en la muestra NEGATIVA.",
                "options": [
                    {
                        "label": "Opción A: Visualización sólo de la línea control patrón #5",
                        "value": "option_a"
                    },
                    {
                        "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                        "value": "option_b"
                    },
                    {
                        "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                        "value": "option_c"
                    }
                ]
            }
        ],
        "evaluation": {
            "rules": [
                {
                    "result": "option_a",
                    "verdict": "fail",
                    "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE (esperado línea control y línea de prueba #4 al #1)"
                },
                {
                    "result": "option_b",
                    "verdict": "pass",
                    "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"
                },
                {
                    "result": "option_c",
                    "verdict": "fail",
                    "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"
                }
            ]
        }
    }',
    write_date = NOW()
WHERE id = 78373;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Especificaciones MAVI-07 para SPHMC01:' as info;

SELECT 
    apsc.id,
    apsc.specification_name,
    apsc.evaluation_type,
    CASE WHEN apsc.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget,
    substring(apsc.text_phrase_mapping::text, 1, 100) as widget_preview
FROM amunet_quality_parameter_specification_config apsc
WHERE apsc.id IN (78308, 78373);

COMMIT;

-- ============================================================================
-- RESUMEN DE CAMBIOS
-- ============================================================================
-- Se actualizaron las especificaciones MAVI-07 para SPHMC01:
-- 
-- 1. "Muestra positiva" (id:78308):
--    - evaluation_type: vama_multi_check -> mavi_07
--    - text_phrase_mapping: Configurado con 3 opciones (A, B, C)
--    - Regla: Opción A = pass, Opción B/C = fail
--
-- 2. "Muestra negativa" (id:78373):
--    - evaluation_type: vama_multi_check -> mavi_07
--    - text_phrase_mapping: Configurado con 3 opciones (A, B, C)
--    - Regla: Opción B = pass, Opción A/C = fail
--
-- Productos con la misma estructura (65 productos SPHMC*):
-- - SPHMC01 a SPHMC74 (con huecos en la numeración)
-- - Todos tienen "Muestra positiva" y "Muestra negativa" con vama_multi_check
-- - Pendiente implementación masiva después de validar SPHMC01
-- ============================================================================
