-- ============================================================================
-- Script de implementación de MAVI-07 para SPHMC01 (Hoja Maestra Covinet Ag)
-- Fecha: 2026-03-02
-- ============================================================================
-- Problema identificado:
-- SPHMC01 tiene MAVI-07 asignado pero NO tiene configuraciones de especificación
-- 
-- Estructura del widget MAVI-07 para Hojas Maestras:
-- - Paso1: Elección de positivo o negativo con dos botones
-- - Paso2: Tres opciones:
--   - Opción A: Visualización sólo de la línea control patrón #5
--   - Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1
--   - Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba
--
-- Criterios de evaluación:
-- - Muestra positiva: Visualización sólo de la línea control patrón #5
-- - Muestra negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1
-- ============================================================================

BEGIN;

-- ============================================================================
-- Paso1: Crear la especificación "Ubicación en el patrón (PRB-01)" para MAVI-07
-- ============================================================================

SELECT 'Creando especificación Ubicación en el patrón (PRB-01)...' as info;

-- Insertar nueva especificación
INSERT INTO amunet_quality_check_parameter_specification (
    name,
    parameter_id,
    create_date,
    write_date
) VALUES (
    'Ubicación en el patrón (PRB-01)',
    65,-- MAVI-07
    NOW(),
    NOW()
) RETURNING id as new_specification_id;

-- ============================================================================
-- Paso2: Crear la configuración MAVI-07 para SPHMC01
-- ============================================================================

SELECT 'Creando configuración MAVI-07 para SPHMC01...' as info;

-- Obtener el ID de la especificación recién creada
DO $$
DECLARE
    v_specification_id INTEGER;
    v_product_tmpl_id INTEGER := 1431;-- SPHMC01
    v_product_parameter_rel_id INTEGER := 537;-- rel_id de MAVI-07 para SPHMC01
BEGIN
    -- Obtener el ID de la especificación
    SELECT id INTO v_specification_id 
    FROM amunet_quality_check_parameter_specification 
    WHERE name = 'Ubicación en el patrón (PRB-01)' AND parameter_id = 65;
    
    -- Insertar la configuración
    INSERT INTO amunet_quality_parameter_specification_config (
        product_parameter_rel_id,
        specification_id,
        sequence,
        product_tmpl_id,
        parameter_id,
        specification_name,
        evaluation_type,
        text_phrase_mapping,
        active,
        create_date,
        write_date
    ) VALUES (
        v_product_parameter_rel_id,
        v_specification_id,
        10,
        v_product_tmpl_id,
        65,-- MAVI-07
        'Ubicación en el patrón (PRB-01)',
        'mavi_07',
        '{"positions": [
            {"index": 0, "type": "select", "label": "1. Tipo de Muestra", "instruction": "Seleccione el tipo de muestra.", "options": [
                {"label": "Muestra Positiva", "value": "positive"},
                {"label": "Muestra Negativa", "value": "negative"}
            ]},
            {"index": 1, "type": "select", "label": "2. Resultado Observado", "instruction": "Seleccione el resultado visualizado.", "options": [
                {"label": "Opción A: Visualización sólo de la línea control patrón #5", "value": "option_a"},
                {"label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1", "value": "option_b"},
                {"label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba", "value": "option_c"}
            ]}
        ], "evaluation": {"rules": [
            {"sample_type": "positive", "result": "option_a", "verdict": "pass", "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"},
            {"sample_type": "positive", "result": "option_b", "verdict": "fail", "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE (esperado sólo línea control #5)"},
            {"sample_type": "positive", "result": "option_c", "verdict": "fail", "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"},
            {"sample_type": "negative", "result": "option_a", "verdict": "fail", "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE (esperado línea control y línea de prueba #4 al #1)"},
            {"sample_type": "negative", "result": "option_b", "verdict": "pass", "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"},
            {"sample_type": "negative", "result": "option_c", "verdict": "fail", "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"}
        ]}}',
        true,
        NOW(),
        NOW()
    );
    
    RAISE NOTICE 'Configuración MAVI-07 creada para SPHMC01 con specification_id: %', v_specification_id;
END $$;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Configuración MAVI-07 para SPHMC01:' as info;

SELECT 
    apsc.id,
    apsc.specification_name,
    apsc.evaluation_type,
    apsc.active,
    CASE WHEN apsc.text_phrase_mapping LIKE '%evaluation%' THEN 'SÍ tiene evaluation' ELSE 'NO tiene evaluation' END as tiene_evaluation
FROM amunet_quality_parameter_specification_config apsc
JOIN product_template pt ON pt.id = apsc.product_tmpl_id
JOIN product_product pp ON pp.product_tmpl_id = pt.id
WHERE pp.default_code = 'SPHMC01' AND apsc.parameter_id = 65;

COMMIT;

-- ============================================================================
-- RESUMEN DE CAMBIOS
-- ============================================================================
-- Se creó la especificación "Ubicación en el patrón (PRB-01)" para MAVI-07
-- Se creó la configuración MAVI-07 para SPHMC01 con:
-- - Paso1: Selección de tipo de muestra (Positiva/Negativa)
-- - Paso2: Tres opciones de resultado (A, B, C)
-- - Reglas de evaluación:
--   - Muestra Positiva: Opción A = pass, Opción B/C = fail
--   - Muestra Negativa: Opción B = pass, Opción A/C = fail
-- ============================================================================
