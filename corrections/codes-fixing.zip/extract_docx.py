import zipfile
import xml.etree.ElementTree as ET
import sys
import io

# Set stdout to utf-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

docx_path = r'c:\odoo-docker\addons\amunet_quality\quality documents\cc\CC Semiterminados.docx'
with zipfile.ZipFile(docx_path, 'r') as z:
    xml_content = z.read('word/document.xml').decode('utf-8')
    tree = ET.fromstring(xml_content)
    texts = []
    for p in tree.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'):
        para_text = ''
        for t in p.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'):
            if t.text:
                para_text += t.text
        if para_text.strip():
            texts.append(para_text.strip())
    
    # Write to file
    with open(r'c:\odoo-docker\corrections\semiterminados_doc.txt', 'w', encoding='utf-8') as f:
        for t in texts:
            f.write(t + '\n')
    print('Extracted to corrections/semiterminados_doc.txt')
