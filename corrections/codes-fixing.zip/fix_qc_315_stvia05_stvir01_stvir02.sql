-- ============================================================================
-- Script de corrección para QC ID 315
-- Fecha: 2026-03-01
-- ============================================================================
-- Este script actualiza directamente las líneas del QC existente para:
-- 1. Eliminar las líneas de detalle de VAMA-096 (test_line_id: 649)
-- 2. Eliminar la línea de prueba VAMA-096
-- 3. Actualizar el tipo de evaluación de MAVI-11 a 'numeric_range'
-- ============================================================================

BEGIN;

-- ============================================================================
-- VERIFICACIÓN PREVIA
-- ============================================================================

SELECT 'Estado actual del QC 315:' as info;

SELECT tl.id, tl.check_id, tl.parameter_id, qp.code as parameter_code, qp.name as parameter_name
FROM amunet_quality_test_line tl
JOIN amunet_quality_check_parameter qp ON qp.id = tl.parameter_id
WHERE tl.check_id = 315
ORDER BY tl.id;

-- ============================================================================
-- PARTE 1: Eliminar líneas de detalle de VAMA-096 (test_line_id: 649)
-- ============================================================================

SELECT 'Eliminando detalles de VAMA-096 (test_line_id: 649):' as info;

SELECT id, name, evaluation_type 
FROM amunet_quality_test_line_detail 
WHERE test_line_id = 649;

-- Eliminar los detalles de VAMA-096
DELETE FROM amunet_quality_test_line_detail 
WHERE test_line_id = 649
RETURNING id, name;

-- ============================================================================
-- PARTE 2: Eliminar la línea de prueba VAMA-096 (test_line_id: 649)
-- ============================================================================

SELECT 'Eliminando línea de prueba VAMA-096:' as info;

DELETE FROM amunet_quality_test_line 
WHERE id = 649 AND check_id = 315
RETURNING id, check_id, parameter_id;

-- ============================================================================
-- PARTE 3: Actualizar tipo de evaluación de MAVI-11 a 'numeric_range'
-- ============================================================================

SELECT 'Actualizando MAVI-11 a numeric_range:' as info;

SELECT id, name, evaluation_type 
FROM amunet_quality_test_line_detail 
WHERE test_line_id = 647 AND evaluation_type = 'mavi_11_height';

-- Actualizar las líneas de detalle de MAVI-11
UPDATE amunet_quality_test_line_detail
SET evaluation_type = 'numeric_range',
    write_date = NOW()
WHERE test_line_id = 647 
  AND evaluation_type = 'mavi_11_height'
RETURNING id, name, evaluation_type;

-- ============================================================================
-- VERIFICACIÓN FINAL
-- ============================================================================

SELECT 'Estado final del QC 315:' as info;

SELECT tl.id, tl.check_id, tl.parameter_id, qp.code as parameter_code, qp.name as parameter_name
FROM amunet_quality_test_line tl
JOIN amunet_quality_check_parameter qp ON qp.id = tl.parameter_id
WHERE tl.check_id = 315
ORDER BY tl.id;

SELECT 'Detalles de MAVI-11 actualizados:' as info;

SELECT id, name, evaluation_type 
FROM amunet_quality_test_line_detail 
WHERE test_line_id = 647
ORDER BY id;

COMMIT;

-- ============================================================================
-- RESUMEN DE CAMBIOS EN QC 315
-- ============================================================================
-- 1. Eliminada línea de prueba VAMA-096 (test_line_id: 649)
-- 2. Eliminados detalles de VAMA-096 (ids: 1475, 1476)
-- 3. Actualizado MAVI-11 a numeric_range (ids: 1470, 1472, 1473)
-- ============================================================================
