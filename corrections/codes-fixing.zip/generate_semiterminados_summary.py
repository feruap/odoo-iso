#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para generar un resumen de productos semiterminados con sus determinaciones.
"""

import subprocess
import sys
import os

# Configurar encoding
os.environ['PYTHONIOENCODING'] = 'utf-8'

def run_query(query):
    """Ejecuta una consulta SQL en el contenedor de base de datos."""
    cmd = [
        'docker', 'exec', '-i', 'odoo-docker-web-db-1', 
        'psql', '-U', 'odoo', '-d', 'amunet_local', 
        '-t', '-A', '-F', '|', '-c', query
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
        if result.returncode != 0:
            return []
        stdout = result.stdout
        if stdout is None:
            return []
        return [line.split('|') for line in stdout.strip().split('\n') if line]
    except Exception as e:
        return []

def get_products():
    """Obtiene la lista de productos semiterminados."""
    query = """
    SELECT DISTINCT pt.default_code, pt.name->>'es_MX' as product_name
    FROM product_template pt
    WHERE pt.default_code LIKE 'ST%'
    ORDER BY pt.default_code;
    """
    return run_query(query)

def get_parameters(product_code):
    """Obtiene los parametros de un producto."""
    query = f"""
    SELECT DISTINCT param.code, param.name
    FROM product_template pt
    JOIN amunet_quality_parameter_product_rel rel ON rel.product_tmpl_id = pt.id
    JOIN amunet_quality_check_parameter param ON param.id = rel.parameter_id
    WHERE pt.default_code = '{product_code}'
    ORDER BY param.code;
    """
    return run_query(query)

def get_specifications(product_code, param_code):
    """Obtiene las especificaciones de un parametro de un producto."""
    query = f"""
    SELECT DISTINCT 
        spec.evaluation_type,
        spec.min_value,
        spec.max_value,
        spec.binary_option_pass,
        spec.binary_option_fail
    FROM product_template pt
    JOIN amunet_quality_parameter_product_rel rel ON rel.product_tmpl_id = pt.id
    JOIN amunet_quality_check_parameter param ON param.id = rel.parameter_id
    LEFT JOIN amunet_quality_parameter_specification_config spec ON spec.product_parameter_rel_id = rel.id
    WHERE pt.default_code = '{product_code}' AND param.code = '{param_code}'
    ORDER BY spec.evaluation_type;
    """
    return run_query(query)

def main():
    output_lines = []
    output_lines.append("=" * 100)
    output_lines.append("RESUMEN DE PRODUCTOS SEMITERMINADOS CON SUS DETERMINACIONES")
    output_lines.append("=" * 100)
    output_lines.append("")
    
    products = get_products()
    
    for product in products:
        if not product or len(product) < 2:
            continue
        product_code, product_name = product[0], product[1] if len(product) > 1 else ''
        
        output_lines.append("")
        output_lines.append("=" * 80)
        output_lines.append(f"PRODUCTO: {product_code} - {product_name}")
        output_lines.append("=" * 80)
        
        parameters = get_parameters(product_code)
        
        if not parameters:
            output_lines.append("  Sin determinaciones configuradas")
            continue
        
        for param in parameters:
            if not param or len(param) < 2:
                continue
            param_code, param_name = param[0], param[1] if len(param) > 1 else ''
            
            output_lines.append("")
            output_lines.append(f"  [*] DETERMINACION: {param_code} - {param_name}")
            output_lines.append("  " + "-" * 60)
            
            specs = get_specifications(product_code, param_code)
            
            if not specs:
                output_lines.append("     [!] Sin especificaciones configuradas")
                continue
            
            # Agrupar por tipo de evaluacion
            eval_types_seen = set()
            for spec in specs:
                if len(spec) < 5:
                    continue
                    
                eval_type = spec[0] if spec[0] else 'N/A'
                min_val = spec[1] if spec[1] else 'N/A'
                max_val = spec[2] if spec[2] else 'N/A'
                pass_opt = spec[3] if len(spec) > 3 and spec[3] else None
                fail_opt = spec[4] if len(spec) > 4 and spec[4] else None
                
                if eval_type in eval_types_seen:
                    continue
                eval_types_seen.add(eval_type)
                
                output_lines.append("")
                output_lines.append(f"     [>] Tipo de Evaluacion: {eval_type}")
                
                # Si es un widget especial
                widget_types = ['conditional_numeric_range', 'mavi_07', 'mavi_07_ternary', 'vama_multi_check']
                if eval_type in widget_types:
                    output_lines.append(f"        [W] WIDGET ESPECIAL: {eval_type}")
                
                if min_val != 'N/A' and max_val != 'N/A':
                    if min_val != max_val:
                        output_lines.append(f"        [R] Rango: {min_val} - {max_val}")
                    else:
                        output_lines.append(f"        [V] Valor objetivo: {min_val}")
                
                if pass_opt:
                    output_lines.append(f"        [OK] Cumple: {pass_opt}")
                if fail_opt:
                    output_lines.append(f"        [X] No cumple: {fail_opt}")
    
    # Escribir resultado
    result = '\n'.join(output_lines)
    with open('corrections/SEMITERMINADOS_SUMMARY.md', 'w', encoding='utf-8') as f:
        f.write(result)
    print(result)

if __name__ == '__main__':
    main()
