# Análisis de Configuración MAVI-11 en Hojas Maestras

## Resumen Ejecutivo

Se detectó que existen productos de Hojas Maestras con la determinación MAVI-11 configurados incorrectamente. El problema radica en el tipo de evaluación (`evaluation_type`) utilizado.

**Fecha de análisis:** 2026-03-02
**Fecha de corrección:** 2026-03-02
**Total de productos SPHMC analizados:** 73 productos
**Productos correctamente configurados (después de corrección):** 73 ✅
**Productos corregidos:** 71

---

## Hallazgo Principal

### Tipo de Evaluación Correcto vs Incorrecto

| Tipo de Evaluación | Estado | Descripción |
|--------------------|--------|-------------|
| `conditional_numeric_range` | ✅ CORRECTO | Permite seleccionar entre 6 u 8 cm y registrar el valor correspondiente |
| `mavi_11_height` | ❌ INCORRECTO | Tipo de evaluación obsoleto que no funciona correctamente |

### Productos de Referencia

- **SPHMC38** (Hoja Maestra PSA semicuantitativa): ✅ Configurado correctamente con `conditional_numeric_range`
- **SPHMC01** (Hoja Maestra Covinet Ag): ❌ Configurado incorrectamente con `mavi_11_height`

---

## Productos Correctamente Configurados (2 productos)

| Código | Nombre | Tipo de Evaluación |
|--------|--------|-------------------|
| SPHMC04 | Hoja Maestra Albumina cualitativa | `conditional_numeric_range` |
| SPHMC38 | Hoja Maestra PSA semicuantitativa | `conditional_numeric_range` |

---

## Productos con Configuración Incorrecta (71 productos)

### Grupo 1: Detección de Antígenos/Virus (10 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC02 | Hoja Maestra Coronavirus | `mavi_11_height` |
| SPHMC15 | Hoja Maestra Influenza A+B | `mavi_11_height` |
| SPHMC19 | Hoja Maestra Dengue NS1 | `mavi_11_height` |
| SPHMC20 | Hoja Maestra RSV | `mavi_11_height` |
| SPHMC23 | Hoja Maestra VIH p24 | `mavi_11_height` |
| SPHMC27 | Hoja Maestra Rotavirus/adenovirus | `mavi_11_height` |
| SPHMC28 | Hoja Maestra Tuberculosis | `mavi_11_height` |
| SPHMC29 | Hoja Maestra Giardia lamblia | `mavi_11_height` |
| SPHMC61 | Hoja Maestra Zika NS1 | `mavi_11_height` |
| SPHMC67 | Hoja Maestra Alcohol en saliva | `mavi_11_height` |

### Grupo 2: Detección de Anticuerpos/Ig (12 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC01 | Hoja Maestra Covinet Ag | `mavi_11_height` |
| SPHMC03 | Hoja Maestra Clamidia IgM Ac | `mavi_11_height` |
| SPHMC05 | Hoja Maestra Chagas | `mavi_11_height` |
| SPHMC06 | Hoja Maestra VIH 1.2 | `mavi_11_height` |
| SPHMC18 | Hoja Maestra Dengue IgG/IgM | `mavi_11_height` |
| SPHMC22 | Hoja Maestra Sifilis | `mavi_11_height` |
| SPHMC40 | Hoja Maestra H. pylori Ac | `mavi_11_height` |
| SPHMC49 | Hoja Maestra ToRCH IgG/IgM | `mavi_11_height` |
| SPHMC56 | Hoja Maestra Chikungunya | `mavi_11_height` |
| SPHMC62 | Hoja Maestra Zika IgG/IgM | `mavi_11_height` |
| SPHMC69 | Hoja Maestra ToRCH IgG | `mavi_11_height` |
| SPHMC70 | Hoja Maestra ToRCH IgM | `mavi_11_height` |

### Grupo 3: Marcadores Cardíacos (5 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC17 | Hoja Maestra Cardiac combo | `mavi_11_height` |
| SPHMC39 | Hoja Maestra Dimero D | `mavi_11_height` |
| SPHMC59 | Hoja Maestra NT-proBNP | `mavi_11_height` |
| SPHMC73 | Hoja Maestra FABP (cardiac combo) | `mavi_11_height` |
| SPHMC74 | Hoja Maestra cTnl I (cardiac combo) | `mavi_11_height` |

### Grupo 4: Marcadores Tumorales (4 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC24 | Hoja Maestra PSA cualitativa | `mavi_11_height` |
| SPHMC33 | Hoja Maestra CA 125 | `mavi_11_height` |
| SPHMC35 | Hoja Maestra CA 19-9 | `mavi_11_height` |
| SPHMC36 | Hoja Maestra Alfafetoproteína | `mavi_11_height` |

### Grupo 5: Pruebas de Drogas/Antidoping (6 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC10 | Hoja Maestra Marihuana (THC) | `mavi_11_height` |
| SPHMC11 | Hoja Maestra Anfetamina (AMP) | `mavi_11_height` |
| SPHMC12 | Hoja Maestra Cocaina (COC) | `mavi_11_height` |
| SPHMC13 | Hoja Maestra Metanfetamina (MET) | `mavi_11_height` |
| SPHMC14 | Hoja Maestra Opiáceos (OPI) | `mavi_11_height` |
| SPHMC53 | Hoja Maestra Antidoping 2 parametros | `mavi_11_height` |
| SPHMC54 | Hoja Maestra Antidoping 3 parametros | `mavi_11_height` |
| SPHMC63 | Hoja Maestra Fentanilo | `mavi_11_height` |

### Grupo 6: Pruebas Hormonales (5 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC09 | Hoja Maestra Vitamina D | `mavi_11_height` |
| SPHMC25 | Hoja Maestra Ferritina | `mavi_11_height` |
| SPHMC26 | Hoja Maestra AMH | `mavi_11_height` |
| SPHMC37 | Hoja Maestra TSH cualitativa | `mavi_11_height` |
| SPHMC52 | Hoja Maestra TSH semicuantitativa | `mavi_11_height` |

### Grupo 7: Pruebas Metabólicas/Bioquímicas (6 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC07 | Hoja Maestra Hemoglobina | `mavi_11_height` |
| SPHMC16 | Hoja Maestra Albumina semicuantitativa | `mavi_11_height` |
| SPHMC42 | Hoja Maestra Factor reumatoide | `mavi_11_height` |
| SPHMC47 | Hoja Maestra Fibronectina | `mavi_11_height` |
| SPHMC50 | Hoja Maestra IgE | `mavi_11_height` |
| SPHMC55 | Hoja Maestra Calprotectina | `mavi_11_height` |

### Grupo 8: Pruebas de Embarazo (2 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC21 | Hoja Maestra hCG multimuestra | `mavi_11_height` |
| SPHMC65 | Hoja Maestra hCG SSP | `mavi_11_height` |

### Grupo 9: Pruebas Bacterianas/Parasitarias (11 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC08 | Hoja Maestra Clamidia | `mavi_11_height` |
| SPHMC31 | Hoja Maestra Entamoeba, Giardia, Crypto | `mavi_11_height` |
| SPHMC32 | Hoja Maestra Mycoplasma | `mavi_11_height` |
| SPHMC41 | Hoja Maestra Tetanos | `mavi_11_height` |
| SPHMC43 | Hoja Maestra Tifoidea | `mavi_11_height` |
| SPHMC44 | Hoja Maestra Campylobacter | `mavi_11_height` |
| SPHMC45 | Hoja Maestra Salmonella typhi | `mavi_11_height` |
| SPHMC46 | Hoja Maestra H. pylori Ag | `mavi_11_height` |
| SPHMC48 | Hoja Maestra Entamoeba | `mavi_11_height` |
| SPHMC60 | Hoja Maestra Shigella | `mavi_11_height` |
| SPHMC71 | Hoja Maestra Gonorrea | `mavi_11_height` |

### Grupo 10: Pruebas Misceláneas (10 productos)

| Código | Nombre | Tipo Actual (Incorrecto) |
|--------|--------|-------------------------|
| SPHMC30 | Hoja Maestra Mononucleosis | `mavi_11_height` |
| SPHMC51 | Hoja Maestra Estreptococcus B | `mavi_11_height` |
| SPHMC57 | Hoja Maestra Estreptococcus A | `mavi_11_height` |
| SPHMC58 | Hoja Maestra Streptococcus pneumoniae | `mavi_11_height` |
| SPHMC64 | Hoja Maestra Transferrina/FOB | `mavi_11_height` |
| SPHMC66 | Hoja Maestra Candida | `mavi_11_height` |
| SPHMC68 | Hoja Maestra pH vaginal | `mavi_11_height` |
| SPHMC72 | Hoja Maestra Cryptococcus | `mavi_11_height` |

---

## Resumen por Tipo de Evaluación

| Tipo de Evaluación | Cantidad | Porcentaje |
|--------------------|----------|------------|
| `conditional_numeric_range` (CORRECTO) | 2 | 2.7% |
| `mavi_11_height` (INCORRECTO) | 71 | 97.3% |
| **Total** | **73** | **100%** |

---

## Recomendación

Se requiere actualizar el tipo de evaluación de `mavi_11_height` a `conditional_numeric_range` para los 71 productos incorrectamente configurados.

### Script de Corrección Sugerido

```sql
-- Actualizar tipo de evaluación de MAVI-11 de 'mavi_11_height' a 'conditional_numeric_range'
-- para productos SPHMC con especificación "Altura 6 u 8 cm"

UPDATE amunet_quality_parameter_specification_config
SET evaluation_type = 'conditional_numeric_range',
    write_date = NOW()
WHERE parameter_id IN (61, 64)  -- MAVI-11: Longitud y Longitud y/o grosor
  AND evaluation_type = 'mavi_11_height'
  AND specification_name LIKE '%Altura 6 u 8 cm%'
  AND active = true
  AND product_tmpl_id IN (
    SELECT pt.id 
    FROM product_template pt 
    JOIN product_product pp ON pp.product_tmpl_id = pt.id 
    WHERE pp.default_code LIKE 'SPHMC%'
  )
RETURNING id, product_tmpl_id, specification_name, evaluation_type;
```

---

*Generado automáticamente - Análisis MAVI-11 Hojas Maestras*
*Fecha: 2026-03-02*
