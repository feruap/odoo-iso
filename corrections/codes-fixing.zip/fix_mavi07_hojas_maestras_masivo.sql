-- ============================================================================
-- Script de corrección MASIVA MAVI-07 para Hojas Maestras (SPHMC*)
-- Fecha: 2026-03-02
-- ============================================================================
-- Este script actualiza TODOS los productos SPHMC* con MAVI-07
-- EJECUTAR SOLO DESPUÉS DE VALIDAR SPHMC01
--
-- Estructura del widget MAVI-07:
-- - Paso1: Tipo de muestra (definido por el nombre de la especificación)
-- - Paso2: Tres opciones de resultado:
--   - Opción A: Visualización sólo de la línea control patrón #5
--   - Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1
--   - Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba
--
-- Criterios de evaluación:
-- - Muestra positiva: Opción A = pass
-- - Muestra negativa: Opción B = pass
-- ============================================================================

BEGIN;

-- ============================================================================
-- GRUPO1: Productos con SOLO "Muestra positiva" y "Muestra negativa"
-- (64 productos - excluyendo SPHMC01 que ya fue actualizado y SPHMC04 que tiene 3 especificaciones)
-- ============================================================================

SELECT 'Actualizando especificaciones MAVI-07 para Hojas Maestras...' as info;

-- Actualizar TODAS las especificaciones "Muestra positiva" de SPHMC* (excluyendo SPHMC01 ya actualizado)
UPDATE amunet_quality_parameter_specification_config apsc
SET 
    evaluation_type = 'mavi_07',
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "type": "select",
                "label": "Resultado Observado",
                "instruction": "Seleccione el resultado visualizado en la muestra POSITIVA.",
                "options": [
                    {
                        "label": "Opción A: Visualización sólo de la línea control patrón #5",
                        "value": "option_a"
                    },
                    {
                        "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                        "value": "option_b"
                    },
                    {
                        "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                        "value": "option_c"
                    }
                ]
            }
        ],
        "evaluation": {
            "rules": [
                {
                    "result": "option_a",
                    "verdict": "pass",
                    "message": "Muestra Positiva: Visualización sólo de la línea control patrón #5 - CUMPLE"
                },
                {
                    "result": "option_b",
                    "verdict": "fail",
                    "message": "Muestra Positiva: Visualización de línea control y línea de prueba - NO CUMPLE (esperado sólo línea control #5)"
                },
                {
                    "result": "option_c",
                    "verdict": "fail",
                    "message": "Muestra Positiva: Sin visualización de línea control - NO CUMPLE"
                }
            ]
        }
    }',
    write_date = NOW()
WHERE apsc.specification_name = 'Muestra positiva'
AND apsc.id IN (
    SELECT apsc2.id FROM amunet_quality_parameter_specification_config apsc2
    JOIN amunet_quality_parameter_product_rel rel ON rel.id = apsc2.product_parameter_rel_id
    JOIN product_template pt ON pt.id = rel.product_tmpl_id
    JOIN product_product pp ON pp.product_tmpl_id = pt.id
    WHERE pp.default_code LIKE 'SPHMC%'
    AND apsc2.specification_name = 'Muestra positiva'
    AND apsc2.evaluation_type = 'vama_multi_check'
);

SELECT 'Actualizadas Muestra positiva: ' || ROW_COUNT() || ' registros' as resultado;

-- Actualizar TODAS las especificaciones "Muestra negativa" de SPHMC* (excluyendo SPHMC01 ya actualizado)
UPDATE amunet_quality_parameter_specification_config apsc
SET 
    evaluation_type = 'mavi_07',
    text_phrase_mapping = '{
        "positions": [
            {
                "index": 0,
                "type": "select",
                "label": "Resultado Observado",
                "instruction": "Seleccione el resultado visualizado en la muestra NEGATIVA.",
                "options": [
                    {
                        "label": "Opción A: Visualización sólo de la línea control patrón #5",
                        "value": "option_a"
                    },
                    {
                        "label": "Opción B: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1",
                        "value": "option_b"
                    },
                    {
                        "label": "Opción C: Sin visualización de la línea control pese a la presencia de líneas de prueba",
                        "value": "option_c"
                    }
                ]
            }
        ],
        "evaluation": {
            "rules": [
                {
                    "result": "option_a",
                    "verdict": "fail",
                    "message": "Muestra Negativa: Visualización sólo de la línea control patrón #5 - NO CUMPLE (esperado línea control y línea de prueba #4 al #1)"
                },
                {
                    "result": "option_b",
                    "verdict": "pass",
                    "message": "Muestra Negativa: Visualización de la línea control y de la línea de prueba dentro del patrón #4 al #1 - CUMPLE"
                },
                {
                    "result": "option_c",
                    "verdict": "fail",
                    "message": "Muestra Negativa: Sin visualización de línea control - NO CUMPLE"
                }
            ]
        }
    }',
    write_date = NOW()
WHERE apsc.specification_name = 'Muestra negativa'
AND apsc.id IN (
    SELECT apsc2.id FROM amunet_quality_parameter_specification_config apsc2
    JOIN amunet_quality_parameter_product_rel rel ON rel.id = apsc2.product_parameter_rel_id
    JOIN product_template pt ON pt.id = rel.product_tmpl_id
    JOIN product_product pp ON pp.product_tmpl_id = pt.id
    WHERE pp.default_code LIKE 'SPHMC%'
    AND apsc2.specification_name = 'Muestra negativa'
    AND apsc2.evaluation_type = 'vama_multi_check'
);

SELECT 'Actualizadas Muestra negativa: ' || ROW_COUNT() || ' registros' as resultado;

-- ============================================================================
-- Verificación
-- ============================================================================

SELECT 'Verificación - Productos SPHMC* con MAVI-07 actualizados:' as info;

SELECT 
    pp.default_code as codigo,
    apsc.specification_name,
    apsc.evaluation_type,
    CASE WHEN apsc.text_phrase_mapping IS NOT NULL THEN 'SÍ configurado' ELSE 'SIN configurar' END as tiene_widget
FROM amunet_quality_parameter_product_rel rel
JOIN product_template pt ON pt.id = rel.product_tmpl_id
JOIN product_product pp ON pp.product_tmpl_id = pt.id
JOIN amunet_quality_check_parameter ap ON ap.id = rel.parameter_id
JOIN amunet_quality_parameter_specification_config apsc ON apsc.product_parameter_rel_id = rel.id
WHERE ap.code = 'MAVI-07' 
AND pp.default_code LIKE 'SPHMC%'
ORDER BY pp.default_code, apsc.specification_name;

COMMIT;

-- ============================================================================
-- RESUMEN DE PRODUCTOS AFECTADOS
-- ============================================================================
-- Total de productos SPHMC* con MAVI-07:65
--
-- Productos con estructura "Muestra positiva" + "Muestra negativa":
-- SPHMC01, SPHMC02, SPHMC03, SPHMC05, SPHMC06, SPHMC08, SPHMC10, SPHMC11,
-- SPHMC12, SPHMC13, SPHMC14, SPHMC15, SPHMC17, SPHMC18, SPHMC19, SPHMC20,
-- SPHMC21, SPHMC22, SPHMC23, SPHMC24, SPHMC27, SPHMC28, SPHMC29, SPHMC30,
-- SPHMC31, SPHMC32, SPHMC33, SPHMC34, SPHMC35, SPHMC36, SPHMC37, SPHMC39,
-- SPHMC40, SPHMC41, SPHMC42, SPHMC43, SPHMC44, SPHMC45, SPHMC46, SPHMC47,
-- SPHMC48, SPHMC49, SPHMC50, SPHMC51, SPHMC53, SPHMC54, SPHMC55, SPHMC56,
-- SPHMC57, SPHMC58, SPHMC59, SPHMC60, SPHMC61, SPHMC62, SPHMC63, SPHMC64,
-- SPHMC65, SPHMC66, SPHMC69, SPHMC70, SPHMC71, SPHMC72, SPHMC73, SPHMC74
--
-- Nota: SPHMC04 tiene una especificación adicional "Interpretación de Líneas"
-- que requiere análisis separado.
-- ============================================================================
